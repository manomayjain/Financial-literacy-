# Smart Personal Finance Coach & Literacy App

A personal finance app for your phone. Users log income and spending, set savings goals, and track recurring subscriptions, and the backend automatically:

- **Warns on overspending** when a month-to-date category total passes its threshold, and links a related article.
- **Reminds users of upcoming bills** (within 3 days of a subscription charge), with correct date handling for short months and leap years.
- **Turns learning into progress** with short articles, 3-question quizzes and badges.

For the full plain-language walkthrough (architecture, database schema, rule engine, tests), see [SYSTEM_DESIGN.md](SYSTEM_DESIGN.md).

## Repository layout

| Folder | What it is | Stack |
|---|---|---|
| [`server/`](server) | Backend REST API (`/api/v1`) | Node, Express, TypeScript, Prisma, PostgreSQL (Neon), Zod, JWT |
| [`mobile/`](mobile) | Android / iOS / web app | Expo, React Native, Expo Router, NativeWind, TanStack Query, Zustand |

## Run it locally

### 1. Backend

```bash
cd server
cp .env.example .env        # then fill in DATABASE_URL and JWT_SECRET
npm install
npx prisma generate
npx prisma migrate dev      # creates the tables
npm run prisma:seed         # loads articles + quizzes
npm run dev                 # http://localhost:4000
```

Health check: `GET http://localhost:4000/api/v1/health`

Run the tests with `npm test` and the type check with `npm run typecheck`.

### 2. Mobile app

```bash
cd mobile
cp .env.example .env        # point EXPO_PUBLIC_API_URL at your backend
npm install
npx expo start              # scan the QR code with Expo Go
```

When testing against a local backend, set `EXPO_PUBLIC_API_URL` to your computer's LAN address, for example `http://192.168.1.100:4000/api/v1`.

## Environment variables

Real `.env` files are git-ignored. Copy the `.env.example` in each folder.

| Where | Variable | Purpose |
|---|---|---|
| `server` | `DATABASE_URL` | PostgreSQL connection string (e.g. Neon) |
| `server` | `JWT_SECRET` | Long random string used to sign tokens |
| `server` | `CLIENT_URL` | Allowed browser origin(s) for CORS |
| `server` | `PORT`, `JWT_EXPIRES_IN`, `JWT_REFRESH_EXPIRES_IN` | Optional overrides |
| `mobile` | `EXPO_PUBLIC_API_URL` | Base URL of the backend API |

## Deployment

- **Backend:** `server/render.yaml` is a Render blueprint and `server/railway.json` is a Railway config. Both run `prisma migrate deploy` before starting.
- **Mobile:** `mobile/eas.json` defines EAS build profiles. `npx eas build --profile preview --platform android` produces an installable APK.

Details are in Appendix B of [SYSTEM_DESIGN.md](SYSTEM_DESIGN.md).

## API testing

A Postman collection covering every endpoint is in [`server/postman/`](server/postman).
