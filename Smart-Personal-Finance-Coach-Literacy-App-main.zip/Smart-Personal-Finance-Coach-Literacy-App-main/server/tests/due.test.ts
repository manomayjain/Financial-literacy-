import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { runSubscriptionDueCheck } from "../src/modules/alerts/due";
import { prisma } from "../src/lib/prisma";

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    subscription: { findMany: vi.fn() },
    alert: { findFirst: vi.fn(), create: vi.fn() },
  },
}));

const mockedPrisma = vi.mocked(prisma);

interface Sub {
  id: string;
  name: string;
  amount: number;
  billingDay: number;
}

function findManyFor(subs: Sub[]) {
  mockedPrisma.subscription.findMany.mockResolvedValue(subs as any);
}

function existingAlert(result: boolean) {
  mockedPrisma.alert.findFirst.mockResolvedValue(result ? { id: "existing" } : null);
  mockedPrisma.alert.create.mockResolvedValue({ id: "new-alert" } as any);
}

const NOW = new Date(2026, 7, 19, 12, 0, 0); // Wednesday 19 Aug 2026

describe("subscription-due rule engine", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(NOW);
    vi.resetAllMocks();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("creates a SUBSCRIPTION_DUE alert for a bill due today", async () => {
    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 19 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    const created = mockedPrisma.alert.create.mock.calls[0][0].data;
    expect(created.userId).toBe("user-1");
    expect(created.type).toBe("SUBSCRIPTION_DUE");
    expect(created.message).toContain("bills today");
    expect(created.message).toContain("$15.99/mo");
  });

  it("creates an alert for a bill due tomorrow", async () => {
    findManyFor([{ id: "sub-1", name: "Spotify", amount: 9.99, billingDay: 20 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    expect(mockedPrisma.alert.create.mock.calls[0][0].data.message).toContain("bills tomorrow");
  });

  it("creates an alert for a bill due in 3 days", async () => {
    findManyFor([{ id: "sub-1", name: "Gym", amount: 40, billingDay: 22 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    expect(mockedPrisma.alert.create.mock.calls[0][0].data.message).toContain("bills in 3 days");
  });

  it("creates alert text for multiple days from now", async () => {
    findManyFor([{ id: "sub-1", name: "Cloud", amount: 5, billingDay: 21 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create.mock.calls[0][0].data.message).toContain("bills in 2 days");
  });

  it("skips subscriptions more than 3 days away", async () => {
    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 23 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("skips subscriptions billing in a future month", async () => {
    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 10 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("de-duplicates: skips when an alert for this billing cycle already exists", async () => {
    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 20 }]);
    existingAlert(true);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("uses the previous billing date as the de-duplication window start", async () => {
    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 20 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    const findWhere = mockedPrisma.alert.findFirst.mock.calls[0][0].where;
    expect(findWhere.userId).toBe("user-1");
    expect(findWhere.type).toBe("SUBSCRIPTION_DUE");
    expect(findWhere.message.startsWith).toBeDefined();
    expect(findWhere.createdAt.gte.getTime()).toBe(
      new Date(2026, 6, 20).getTime(), // previous billing = 20 Jul 2026
    );
  });

  it("handles a 31st-billing day in a short February and clamps it", async () => {
    // Late February, non-leap year: billingDay 31 → Feb 28 (clamped), 3 days out.
    vi.setSystemTime(new Date(2026, 1, 25, 12, 0, 0));

    findManyFor([{ id: "sub-1", name: "Netflix", amount: 15.99, billingDay: 31 }]);
    existingAlert(false);

    await runSubscriptionDueCheck("user-1");

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    expect(mockedPrisma.alert.create.mock.calls[0][0].data.message).toContain("bills in 3 days");

    const findWhere = mockedPrisma.alert.findFirst.mock.calls[0][0].where;
    expect(findWhere.createdAt.gte.getTime()).toBe(
      new Date(2026, 0, 31).getTime(), // previous billing = 31 Jan 2026
    );
  });

  it("swallows database errors so re-fetching alerts is never blocked", async () => {
    mockedPrisma.subscription.findMany.mockRejectedValueOnce(new Error("boom"));

    await expect(runSubscriptionDueCheck("user-1")).resolves.toBeUndefined();
  });
});