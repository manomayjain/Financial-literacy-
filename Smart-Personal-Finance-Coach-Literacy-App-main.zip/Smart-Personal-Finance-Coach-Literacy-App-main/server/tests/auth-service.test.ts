import bcrypt from "bcrypt";
import { Prisma } from "@prisma/client";
import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  getUserById,
  login,
  refresh,
  signup,
} from "../src/modules/auth/auth.service";
import { signRefreshToken } from "../src/utils/jwt";
import { AppError } from "../src/middleware/error.middleware";
import { prisma } from "../src/lib/prisma";

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    user: { create: vi.fn(), findUnique: vi.fn() },
  },
}));

const mockedPrisma = vi.mocked(prisma);

const userRecord = {
  id: "user-1",
  name: "Ada Lovelace",
  email: "ada@example.com",
};
const password = "correct-horse-battery-staple";
const passwordHash = bcrypt.hashSync(password, 4);

function p2002(): Prisma.PrismaClientKnownRequestError {
  return new Prisma.PrismaClientKnownRequestError("Unique constraint failed", {
    code: "P2002",
    clientVersion: "5.22.0",
  });
}

const serverError = (): Prisma.PrismaClientKnownRequestError =>
  new Prisma.PrismaClientKnownRequestError("connection lost", {
    code: "P1001",
    clientVersion: "5.22.0",
  });

describe("auth.service.signup", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("creates a user, hashes the password, and returns tokens", async () => {
    mockedPrisma.user.create.mockResolvedValue(userRecord as any);

    const result = await signup({
      name: userRecord.name,
      email: userRecord.email,
      password,
    });

    const createData = mockedPrisma.user.create.mock.calls[0][0].data as any;
    expect(createData.name).toBe(userRecord.name);
    expect(createData.email).toBe(userRecord.email);
    expect(createData.passwordHash.startsWith("$2")).toBe(true);
    expect(createData.passwordHash).not.toBe(password);

    expect(await bcrypt.compare(password, createData.passwordHash)).toBe(true);
    expect(result.user).toEqual(userRecord);
    expect(result.accessToken).toBeDefined();
    expect(result.refreshToken).toBeDefined();
  });

  it("returns 409 EMAIL_TAKEN when the email already exists", async () => {
    mockedPrisma.user.create.mockRejectedValueOnce(p2002());

    await expect(
      signup({ name: userRecord.name, email: userRecord.email, password }),
    ).rejects.toMatchObject({
      statusCode: 409,
      code: "EMAIL_TAKEN",
    });
  });

  it("re-throws unrelated database errors unchanged", async () => {
    const err = serverError();
    mockedPrisma.user.create.mockRejectedValueOnce(err);

    await expect(
      signup({ name: userRecord.name, email: userRecord.email, password }),
    ).rejects.toBe(err);
  });
});

describe("auth.service.login", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("succeeds with the correct password", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue({
      ...userRecord,
      passwordHash,
    } as any);

    const result = await login({ email: userRecord.email, password });

    expect(result.user).toEqual(userRecord);
    expect(result.accessToken).toBeDefined();
    expect(result.refreshToken).toBeDefined();
  });

  it("rejects a wrong password with 401 INVALID_CREDENTIALS", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue({
      ...userRecord,
      passwordHash,
    } as any);

    const promise = login({ email: userRecord.email, password: "wrong-password" });

    await expect(promise).rejects.toMatchObject({
      statusCode: 401,
      code: "INVALID_CREDENTIALS",
    });
  });

  it("does not reveal whether an account exists (unknown email -> 401)", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue(null);

    await expect(
      login({ email: "ghost@example.com", password }),
    ).rejects.toMatchObject({
      statusCode: 401,
      code: "INVALID_CREDENTIALS",
    });
  });

  it("scopes the lookup by the provided email", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue(null);

    await login({ email: userRecord.email, password }).catch(() => undefined);

    expect(mockedPrisma.user.findUnique.mock.calls[0][0].where.email).toBe(
      userRecord.email,
    );
  });
});

describe("auth.service.refresh", () => {
  it("returns a fresh token pair for a valid refresh token", () => {
    const refreshToken = signRefreshToken({
      userId: userRecord.id,
      email: userRecord.email,
    });
    const result = refresh(refreshToken);
    expect(result.accessToken).toBeDefined();
    expect(result.refreshToken).toBeDefined();
  });

  it("rejects a garbage token with 401 INVALID_REFRESH_TOKEN", () => {
    expect(() => refresh("not-a-valid-jwt")).toThrow(
      expect.objectContaining({
        statusCode: 401,
        code: "INVALID_REFRESH_TOKEN",
      }) as AppError,
    );
  });
});

describe("auth.service.getUserById", () => {
  it("returns the public user for an existing id", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue(userRecord as any);

    await expect(getUserById("user-1")).resolves.toEqual(userRecord);
  });

  it("throws 404 USER_NOT_FOUND for an unknown id", async () => {
    mockedPrisma.user.findUnique.mockResolvedValue(null);

    await expect(getUserById("ghost")).rejects.toMatchObject({
      statusCode: 404,
      code: "USER_NOT_FOUND",
    });
  });
});