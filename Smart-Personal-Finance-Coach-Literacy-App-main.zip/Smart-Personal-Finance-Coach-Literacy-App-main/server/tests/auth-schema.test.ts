import { describe, expect, it } from "vitest";
import {
  loginSchema,
  refreshSchema,
  signupSchema,
} from "../src/modules/auth/auth.schema";

describe("signupSchema (validation rules)", () => {
  const valid = {
    name: "Ada Lovelace",
    email: "ada@example.com",
    password: "correct-horse-battery-staple",
  };

  it("accepts a valid signup", () => {
    expect(signupSchema.safeParse(valid).success).toBe(true);
  });

  it("lowercases the email", () => {
    const result = signupSchema.safeParse({ ...valid, email: "ADA@Example.COM " });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.email).toBe("ada@example.com");
  });

  it.each([
    ["empty name", { ...valid, name: "" }],
    ["too-short name", { ...valid, name: "A" }],
    ["invalid email", { ...valid, email: "not-an-email" }],
    ["empty email", { ...valid, email: "" }],
    ["short password", { ...valid, password: "1234567" }],
    ["empty password", { ...valid, password: "" }],
  ])("rejects %s", (_label, input) => {
    expect(signupSchema.safeParse(input).success).toBe(false);
  });

  it("rejects a password over 72 bytes (bcrypt limit)", () => {
    const result = signupSchema.safeParse({ ...valid, password: "x".repeat(73) });
    expect(result.success).toBe(false);
  });
});

describe("loginSchema", () => {
  it("accepts a valid login", () => {
    expect(
      loginSchema.safeParse({ email: "ada@example.com", password: "password" }).success,
    ).toBe(true);
  });

  it("rejects a missing password", () => {
    expect(loginSchema.safeParse({ email: "ada@example.com" }).success).toBe(false);
  });

  it("rejects a missing email", () => {
    expect(loginSchema.safeParse({ password: "password" }).success).toBe(false);
  });

  it("rejects an invalid email shape", () => {
    expect(
      loginSchema.safeParse({ email: "nope", password: "password" }).success,
    ).toBe(false);
  });
});

describe("refreshSchema", () => {
  it("accepts a non-empty refresh token", () => {
    expect(refreshSchema.safeParse({ refreshToken: "abc.def.ghi" }).success).toBe(true);
  });

  it("rejects an empty refresh token", () => {
    expect(refreshSchema.safeParse({ refreshToken: "" }).success).toBe(false);
  });

  it("rejects a missing refresh token", () => {
    expect(refreshSchema.safeParse({}).success).toBe(false);
  });
});