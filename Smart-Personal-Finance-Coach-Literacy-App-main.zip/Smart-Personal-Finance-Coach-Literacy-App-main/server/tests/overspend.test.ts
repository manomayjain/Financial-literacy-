import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  runOverspendCheck,
  thresholdForCategory,
  monthStartOf,
  nextMonthStart,
  buildOverspendMessage,
} from "../src/modules/alerts/overspend";
import { prisma } from "../src/lib/prisma";

vi.mock("../src/lib/prisma", () => ({
  prisma: {
    entry: { aggregate: vi.fn() },
    alert: { findFirst: vi.fn(), create: vi.fn() },
    article: { findFirst: vi.fn() },
  },
}));

const mockedPrisma = vi.mocked(prisma);

const day = (y: number, m: number, d: number) => new Date(y, m - 1, d);

function runCheck(
  overrides: { spent?: number; existing?: boolean; article?: { id: string } | null } = {},
) {
  const { spent = 0, existing = false, article = null } = overrides;

  mockedPrisma.entry.aggregate.mockResolvedValueOnce({
    _sum: { amount: spent },
    _count: { _all: 0 },
    _avg: { amount: null },
    _max: { amount: null },
    _min: { amount: null },
  } as any);
  mockedPrisma.alert.findFirst.mockResolvedValueOnce(
    existing ? { id: "existing" } : null,
  );
  mockedPrisma.article.findFirst.mockResolvedValueOnce(article);
  mockedPrisma.alert.create.mockResolvedValue({ id: "new-alert" } as any);
}

describe("overspend rule engine: pure helpers", () => {
  it("knows each category's threshold", () => {
    expect(thresholdForCategory("Groceries")).toBe(600);
    expect(thresholdForCategory("Dining")).toBe(400);
    expect(thresholdForCategory("Unknown")).toBe(400); // default
  });

  it("collapses any date to the first of its month", () => {
    expect(monthStartOf(day(2026, 8, 19))).toEqual(day(2026, 8, 1));
    expect(monthStartOf(day(2026, 12, 31))).toEqual(day(2026, 12, 1));
  });

  it("advances a month start to the first of the next month", () => {
    expect(nextMonthStart(day(2026, 8, 1))).toEqual(day(2026, 9, 1));
    expect(nextMonthStart(day(2026, 12, 1))).toEqual(day(2027, 1, 1));
  });

  it("formats overspend messages with the category and money amounts", () => {
    const message = buildOverspendMessage("Dining", 512.5, 400);
    expect(message).toContain("[Dining]");
    expect(message).toContain("$512.50");
    expect(message).toContain("$400.00");
  });
});

describe("overspend rule engine: alert firing", () => {
  beforeEach(() => {
    vi.resetAllMocks();
  });

  it("creates an OVERSPEND alert when a category passes its threshold", async () => {
    runCheck({ spent: 600, article: null });

    await runOverspendCheck("user-1", "EXPENSE", "Other", day(2026, 8, 5));

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    const created = mockedPrisma.alert.create.mock.calls[0][0].data;
    expect(created.userId).toBe("user-1");
    expect(created.type).toBe("OVERSPEND");
    expect(created.message).toContain("[Other]");
    expect(created.articleId).toBeNull();
  });

  it("does nothing for income entries", async () => {
    runCheck();

    await runOverspendCheck("user-1", "INCOME", "Salary", day(2026, 8, 5));

    expect(mockedPrisma.entry.aggregate).not.toHaveBeenCalled();
    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("does not fire at or below the threshold", async () => {
    runCheck({ spent: 400 }); // Other threshold is 500

    await runOverspendCheck("user-1", "EXPENSE", "Other", day(2026, 8, 5));

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("does not fire when the aggregate is exactly the threshold", async () => {
    runCheck({ spent: 500 });

    await runOverspendCheck("user-1", "EXPENSE", "Other", day(2026, 8, 5));

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("links the alert to a matching article when one exists", async () => {
    runCheck({ spent: 700, article: { id: "article-9" } });

    await runOverspendCheck("user-1", "EXPENSE", "Shopping", day(2026, 8, 5));

    expect(mockedPrisma.alert.create).toHaveBeenCalledTimes(1);
    expect(mockedPrisma.alert.create.mock.calls[0][0].data.articleId).toBe("article-9");
  });

  it("de-duplicates: skips when an alert for this category+month already exists", async () => {
    runCheck({ spent: 700, existing: true });

    await runOverspendCheck("user-1", "EXPENSE", "Other", day(2026, 8, 5));

    expect(mockedPrisma.alert.create).not.toHaveBeenCalled();
  });

  it("only counts expense totals within the same calendar month", async () => {
    runCheck({ spent: 600 });

    await runOverspendCheck("user-1", "EXPENSE", "Dining", day(2026, 8, 31));

    const aggregateWhere = mockedPrisma.entry.aggregate.mock.calls[0][0].where;
    expect(aggregateWhere.type).toBe("EXPENSE");
    expect(aggregateWhere.category).toBe("Dining");
    expect(aggregateWhere.date.gte).toEqual(day(2026, 8, 1));
    expect(aggregateWhere.date.lt).toEqual(day(2026, 9, 1));
  });

  it("scopes the aggregate query to the user", async () => {
    runCheck({ spent: 600 });

    await runOverspendCheck("user-1", "EXPENSE", "Dining", day(2026, 8, 5));

    expect(mockedPrisma.entry.aggregate.mock.calls[0][0].where.userId).toBe("user-1");
  });

  it("swallows database errors so entry creation is never blocked", async () => {
    mockedPrisma.entry.aggregate.mockRejectedValueOnce(new Error("boom"));

    await expect(runOverspendCheck("user-1", "EXPENSE", "Dining", day(2026, 8, 5))).resolves.toBeUndefined();
  });
});