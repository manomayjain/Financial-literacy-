import { describe, expect, it } from "vitest";
import {
  clampBillingDay,
  daysInMonth,
  daysUntilNextBilling,
  getNextBillingDate,
  getPreviousBillingDate,
} from "../src/utils/billing";

const day = (y: number, m: number, d: number) => new Date(y, m - 1, d);

describe("daysInMonth", () => {
  it("returns 29 in a leap February", () => {
    expect(daysInMonth(2024, 1)).toBe(29);
  });

  it("returns 28 in a non-leap February", () => {
    expect(daysInMonth(2023, 1)).toBe(28);
  });

  it("returns 31 for August", () => {
    expect(daysInMonth(2026, 7)).toBe(31);
  });

  it("returns 30 for April", () => {
    expect(daysInMonth(2026, 3)).toBe(30);
  });
});

describe("clampBillingDay", () => {
  it("keeps days within the month", () => {
    expect(clampBillingDay(2026, 7, 15)).toBe(15);
  });

  it("clamps the 31st into February (non-leap)", () => {
    expect(clampBillingDay(2026, 1, 31)).toBe(28);
  });

  it("clamps the 31st into February (leap year)", () => {
    expect(clampBillingDay(2024, 1, 31)).toBe(29);
  });

  it("clamps the 31st into a 30-day month", () => {
    expect(clampBillingDay(2026, 3, 31)).toBe(30);
  });
});

describe("getNextBillingDate", () => {
  it("resolves to today when the billing day is today", () => {
    expect(getNextBillingDate(10, day(2026, 8, 10))).toEqual(day(2026, 8, 10));
  });

  it("resolves to later in the current month", () => {
    expect(getNextBillingDate(15, day(2026, 8, 10))).toEqual(day(2026, 8, 15));
  });

  it("rolls over to the following month once the billing day has passed", () => {
    expect(getNextBillingDate(10, day(2026, 8, 11))).toEqual(day(2026, 9, 10));
  });

  it("rolls over to the next year from December", () => {
    expect(getNextBillingDate(10, day(2026, 12, 15))).toEqual(day(2027, 1, 10));
  });

  it("clamps the 31st to the end of a non-leap February", () => {
    expect(getNextBillingDate(31, day(2026, 2, 5))).toEqual(day(2026, 2, 28));
  });

  it("clamps the 31st to 29 Feb in a leap year", () => {
    expect(getNextBillingDate(31, day(2024, 2, 5))).toEqual(day(2024, 2, 29));
  });

  it("clamps the 30th to 29 Feb in a leap year", () => {
    expect(getNextBillingDate(30, day(2024, 2, 5))).toEqual(day(2024, 2, 29));
  });

  it("does not roll a Feb-29 billing day into March of the same month", () => {
    expect(getNextBillingDate(29, day(2024, 2, 29))).toEqual(day(2024, 2, 29));
  });

  it("handles a January billing day in December", () => {
    expect(getNextBillingDate(1, day(2026, 12, 15))).toEqual(day(2027, 1, 1));
  });
});

describe("daysUntilNextBilling", () => {
  it("returns 0 when billing is today", () => {
    expect(daysUntilNextBilling(10, day(2026, 8, 10))).toBe(0);
  });

  it("returns 1 when billing is tomorrow", () => {
    expect(daysUntilNextBilling(20, day(2026, 8, 19))).toBe(1);
  });

  it("counts days to the next billing", () => {
    expect(daysUntilNextBilling(15, day(2026, 8, 10))).toBe(5);
  });

  it("counts days across a month boundary", () => {
    expect(daysUntilNextBilling(3, day(2026, 8, 30))).toBe(4);
  });
});

describe("getPreviousBillingDate", () => {
  it("returns the immediately preceding billing date", () => {
    expect(getPreviousBillingDate(10, day(2026, 8, 11))).toEqual(day(2026, 8, 10));
  });

  it("walks back into the previous month", () => {
    expect(getPreviousBillingDate(15, day(2026, 4, 10))).toEqual(day(2026, 3, 15));
  });

  it("walks back into the previous year", () => {
    expect(getPreviousBillingDate(15, day(2026, 1, 10))).toEqual(day(2025, 12, 15));
  });

  it("clamps the previous billing day in a shorter month", () => {
    expect(getPreviousBillingDate(31, day(2026, 4, 10))).toEqual(day(2026, 3, 31));
  });
});