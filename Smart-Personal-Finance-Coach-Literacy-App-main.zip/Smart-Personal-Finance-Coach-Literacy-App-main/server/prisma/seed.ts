import "dotenv/config";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

interface SeedArticle {
  title: string;
  summary: string;
  tag: string;
  body: string;
  quiz: {
    questions: {
      text: string;
      options: string[];
      correctIndex: number;
    }[];
  };
}

const ARTICLES: SeedArticle[] = [
  {
    title: "Grocery Shopping Without Wasting Cash",
    summary:
      "A few simple habits keep your grocery bill down without cutting the foods you love.",
    tag: "food",
    body:
      "Grocery shopping feels small each trip, but it adds up to a big part of your budget. The trick is to plan, not to buy less.\n\n" +
      "Start by checking what you already have in your fridge and cupboard. Then plan your meals for the week around those items. This stops you from buying things you already own.\n\n" +
      "Make a list before you walk in and stick to it. Shop after a meal, not while hungry, because hunger makes you grab extra snacks. Compare prices on the shelf, and try store brands where they look the same.\n\n" +
      "A little planning at home saves real money every single week.",
    quiz: {
      questions: [
        {
          text: "What is the best first step to cut grocery costs?",
          options: [
            "Plan your meals around what you already have",
            "Buy the biggest pack of everything",
            "Shop while hungry",
            "Only buy snack foods",
          ],
          correctIndex: 0,
        },
        {
          text: "Why does shopping on an empty stomach cause problems?",
          options: [
            "It makes you buy more impulse snacks",
            "It makes you follow your list",
            "It makes you compare prices",
            "It makes you buy store brands",
          ],
          correctIndex: 0,
        },
        {
          text: "What should you do before heading to the store?",
          options: [
            "Throw out your list",
            "Write a shopping list",
            "Eat nothing all day",
            "Buy the same items every time",
          ],
          correctIndex: 1,
        },
      ],
    },
  },
  {
    title: "Cheap Eats Without the Guilt",
    summary:
      "Eating out less often doesn't mean boring food. Small kitchen habits save the difference.",
    tag: "food",
    body:
      "Eating out is convenient, but it is one of the easiest places to overspend. You don't need to quit restaurants forever, just tip the balance.\n\n" +
      "Cook at home a few more times each week. Cooking for yourself usually costs a fraction of a restaurant meal, and you control the portions. Batch cooking on Sunday gives you ready-made meals for busy weekdays.\n\n" +
      "Use leftovers for lunch the next day instead of buying takeout. When you do go out, pick a couple of your favorite spots and treat them as a special occasion.\n\n" +
      "You'll eat well, waste less food, and keep more cash in your pocket.",
    quiz: {
      questions: [
        {
          text: "Cooking at home is usually ______ than eating out.",
          options: ["cheaper", "more expensive", "the same", "impossible"],
          correctIndex: 0,
        },
        {
          text: "What does batch cooking give you?",
          options: [
            "Ready-made meals all week",
            "More restaurant bills",
            "Extra junk food",
            "Nothing useful",
          ],
          correctIndex: 0,
        },
        {
          text: "What can you do with leftovers to save money?",
          options: [
            "Throw them out",
            "Order takeout instead",
            "Pack them for tomorrow's lunch",
            "Feed them to the dog",
          ],
          correctIndex: 2,
        },
      ],
    },
  },
  {
    title: "Have Fun for Less",
    summary:
      "Great weekends don't need a big budget. Free and low-cost fun is everywhere once you look.",
    tag: "entertainment",
    body:
      "Fun is important, but it shouldn't wreck your budget. There are plenty of ways to enjoy yourself without spending a lot.\n\n" +
      "Check your local events calendar for free concerts, markets, and park days. Libraries lend books, movies, and even passes to museums. A hike or a bike ride costs almost nothing.\n\n" +
      "When you do pay for entertainment, compare prices first. Look for student, senior, or early-bird discounts. Sharing a streaming account with family splits the monthly cost into tiny pieces.\n\n" +
      "Entertainment is about the experience, not the price tag.",
    quiz: {
      questions: [
        {
          text: "Which of these is a low-cost way to have fun?",
          options: [
            "A free local park event",
            "A brand-new concert every week",
            "Five streaming services alone",
            "A shopping spree",
          ],
          correctIndex: 0,
        },
        {
          text: "Sharing a streaming account with family can ______ your monthly cost.",
          options: ["cut", "double", "triple", "ignore"],
          correctIndex: 0,
        },
        {
          text: "Before buying tickets, a smart move is to:",
          options: [
            "Pay full price without looking",
            "Compare prices and look for discounts",
            "Buy the most expensive seat",
            "Skip the event entirely",
          ],
          correctIndex: 1,
        },
      ],
    },
  },
  {
    title: "A Big Night Out on a Small Budget",
    summary:
      "You can still have a great night out. The secret is deciding your limit before you go.",
    tag: "entertainment",
    body:
      "A night out with friends is fun, but the bill can sneak up on you. Plan ahead and the fun stays fun.\n\n" +
      "Decide how much you want to spend before you leave the house, and bring only that amount. Eat a good meal at home first so you're not paying restaurant prices when you're already full.\n\n" +
      "When splitting the bill, ask the waiter to split it fairly instead of dividing everything equally. You pay for what you actually ordered.\n\n" +
      "A budget for the night means zero surprise bills the next morning.",
    quiz: {
      questions: [
        {
          text: "When should you set your spending limit for a night out?",
          options: [
            "Before you leave home",
            "After the bill arrives",
            "When the party is over",
            "Never",
          ],
          correctIndex: 0,
        },
        {
          text: "Eating a meal at home before going out helps you:",
          options: [
            "Spend less on food out",
            "Order the biggest platter",
            "Drink more",
            "Forget your budget",
          ],
          correctIndex: 0,
        },
        {
          text: "The fairest way to split a shared bill is to:",
          options: [
            "Split it evenly no matter what",
            "Pay only for what you ordered",
            "Let one friend pay for all",
            "Skip paying entirely",
          ],
          correctIndex: 1,
        },
      ],
    },
  },
  {
    title: "Shop Smarter, Not More",
    summary:
      "Slow down your buying. A little patience and comparison saves a surprising amount.",
    tag: "shopping",
    body:
      "Most of us buy too fast. The shiny thing looks good in the moment, but the regret lasts longer than the joy.\n\n" +
      "Try the 24-hour rule: when you want something non-essential, wait a full day before buying. You'll be surprised how many things you no longer want tomorrow.\n\n" +
      "Compare prices before you buy, not after. Check two or three stores or websites for the same item. Add things to a wishlist instead of buying on the spot.\n\n" +
      "Shopping with your head instead of your feelings keeps your budget in one piece.",
    quiz: {
      questions: [
        {
          text: "The 24-hour rule means you:",
          options: [
            "Wait a day before buying non-essentials",
            "Buy everything within 24 hours",
            "Shop only at night",
            "Return things after a day",
          ],
          correctIndex: 0,
        },
        {
          text: "Why compare prices before buying?",
          options: [
            "To find the better deal",
            "To make the line longer",
            "To buy more items",
            "To skip the receipt",
          ],
          correctIndex: 0,
        },
        {
          text: "A wishlist helps you avoid:",
          options: [
            "Impulse buys",
            "Saving money",
            "Making lists",
            "Finding deals",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
  {
    title: "Stop the Impulse Buy",
    summary:
      "Impulse buying is a habit, not a personality. Simple tricks make it much easier to resist.",
    tag: "shopping",
    body:
      "Impulse buys feel great for a second and bad for a month. Stores and apps are designed to trigger them, but you can fight back.\n\n" +
      "Unsubscribe from sale emails and turn off app notifications. If you don't see the deal, you won't feel the urge.\n\n" +
      "Give yourself a small 'fun money' amount each month. When you see something you want, pay for it from that pot. It lets you treat yourself without guilt and without wrecking your plan.\n\n" +
      "Before you buy, pause and ask: do I need this, or do I just want the feeling of buying it?",
    quiz: {
      questions: [
        {
          text: "Unsubscribing from sale emails helps by:",
          options: [
            "Removing temptation before it starts",
            "Finding more sales",
            "Making you buy faster",
            "Deleting your account",
          ],
          correctIndex: 0,
        },
        {
          text: "A small 'fun money' budget lets you:",
          options: [
            "Treat yourself without guilt",
            "Spend without any limit",
            "Ignore your budget",
            "Borrow from savings",
          ],
          correctIndex: 0,
        },
        {
          text: "When you feel the urge to buy, the first step is to:",
          options: [
            "Pause and ask if you really need it",
            "Buy it immediately",
            "Add it to a loan",
            "Ignore it forever",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
  {
    title: "Taming Subscription Fatigue",
    summary:
      "Small monthly fees add up fast. Learn how to audit and cut recurring costs.",
    tag: "subscriptions",
    body:
      "Subscriptions quietly drain budgets. A few dollars here and there becomes a huge monthly total before you notice.\n\n" +
      "Start with an audit. Pull your bank statement and list every recurring charge. You'll often find services you forgot you had.\n\n" +
      "Cancel the ones you don't really use. For the rest, consider sharing a plan with family or switching to the annual rate if it's cheaper.\n\n" +
      "Review your subscriptions every few months. A clean list means more money for what actually matters.",
    quiz: {
      questions: [
        {
          text: "Which of these is the best first step to cut subscription costs?",
          options: [
            "Audit all recurring charges",
            "Cancel the cheapest one immediately",
            "Ignore unused subscriptions",
            "Only track annual plans",
          ],
          correctIndex: 0,
        },
        {
          text: "How often should you review your subscriptions?",
          options: ["Never", "Every few months", "Once a decade", "Every hour"],
          correctIndex: 1,
        },
        {
          text: "Cancelling an unused subscription:",
          options: [
            "Frees money every month",
            "Saves nothing",
            "Increases your bill",
            "Removes your account",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
  {
    title: "Build a Rainy Day Fund",
    summary:
      "Why an emergency fund keeps you out of debt when surprises hit.",
    tag: "saving-basics",
    body:
      "Life throws curveballs: a broken phone, a car repair, a surprise bill. Without a safety net, these become debt.\n\n" +
      "A rainy day fund is money set aside for unexpected costs. A good goal is three to six months of basic expenses, but even a small start helps.\n\n" +
      "Start tiny. Automate a small transfer to a savings account on every payday. You won't miss money you never see.\n\n" +
      "It's not about being perfect. It's about having something ready when life happens.",
    quiz: {
      questions: [
        {
          text: "A rainy day fund is for:",
          options: [
            "Unexpected costs",
            "A yearly vacation",
            "A new car",
            "Everyday coffee",
          ],
          correctIndex: 0,
        },
        {
          text: "A good emergency fund goal is ______ of expenses.",
          options: [
            "Three to six months",
            "One week",
            "Two years",
            "Zero",
          ],
          correctIndex: 0,
        },
        {
          text: "Why automate small transfers on payday?",
          options: [
            "You save without thinking about it",
            "It spends the money faster",
            "It cancels your savings",
            "It doubles your rent",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
  {
    title: "The 50/30/20 Budget Rule",
    summary:
      "A simple framework to split your income into needs, wants, and savings.",
    tag: "budgeting-basics",
    body:
      "Budgeting sounds complicated, but the 50/30/20 rule makes it simple.\n\n" +
      "Spend 50% of your take-home income on needs: rent, groceries, transport, utilities. These are the bills you can't skip.\n\n" +
      "Spend 30% on wants: dining out, entertainment, hobbies. These are nice-to-haves that make life fun.\n\n" +
      "Put 20% toward savings and paying off debt. This builds your future and shrinks what you owe.\n\n" +
      "The percentages are a guide, not a law. Adjust them to fit your life, but keep the habit.",
    quiz: {
      questions: [
        {
          text: "In the 50/30/20 rule, needs get ______ of your income.",
          options: ["30%", "50%", "20%", "80%"],
          correctIndex: 1,
        },
        {
          text: "The 20% bucket is reserved for:",
          options: [
            "Wants",
            "Rent",
            "Savings and debt payoff",
            "Entertainment",
          ],
          correctIndex: 2,
        },
        {
          text: "Which of these counts as a 'want'?",
          options: [
            "Dining out and entertainment",
            "Rent",
            "Groceries",
            "Utility bills",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
  {
    title: "Try a 7-Day No-Spend Challenge",
    summary:
      "One week of spending only on essentials shows you exactly where your money goes.",
    tag: "budgeting-basics",
    body:
      "A no-spend challenge is a week where you only buy essentials: food, bills, and transport. Everything else gets a pause.\n\n" +
      "Plan your meals for the week so you don't order takeout. Find free fun: walks, books from the library, movie night at home.\n\n" +
      "The goal isn't to suffer. It's to notice how often you buy things out of habit instead of need.\n\n" +
      "After the week, you'll have extra cash and a clearer picture of your spending patterns.",
    quiz: {
      questions: [
        {
          text: "During a no-spend week, you should only buy:",
          options: [
            "Essentials",
            "Whatever is on sale",
            "New clothes",
            "Takeout",
          ],
          correctIndex: 0,
        },
        {
          text: "Why plan your meals during the challenge?",
          options: [
            "So you don't fall back on takeout",
            "So you spend more",
            "So you can snack a lot",
            "So you skip dinner",
          ],
          correctIndex: 0,
        },
        {
          text: "A no-spend challenge mainly helps you:",
          options: [
            "See where your money actually goes",
            "Spend more next week",
            "Ignore your bills",
            "Buy bigger items",
          ],
          correctIndex: 0,
        },
      ],
    },
  },
];

async function main() {
  await prisma.question.deleteMany();
  await prisma.quiz.deleteMany();
  await prisma.article.deleteMany();

  for (const article of ARTICLES) {
    const created = await prisma.article.create({
      data: {
        title: article.title,
        summary: article.summary,
        body: article.body,
        tag: article.tag,
      },
    });

    await prisma.quiz.create({
      data: {
        articleId: created.id,
        questions: { create: article.quiz.questions },
      },
    });
  }

  console.log(`Seeded ${ARTICLES.length} articles with quizzes.`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
