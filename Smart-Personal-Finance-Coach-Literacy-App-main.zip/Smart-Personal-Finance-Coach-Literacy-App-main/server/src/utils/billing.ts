export const MS_PER_DAY = 86_400_000;

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

export function clampBillingDay(
  year: number,
  month: number,
  billingDay: number,
): number {
  return Math.min(billingDay, daysInMonth(year, month));
}

function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

/**
 * Next billing date for a recurring bill with `billingDay` (1-31), relative
 * to `from`. Days 28-31 roll over to the last day of a shorter month
 * (e.g. billingDay 31 in February becomes the month's final day). A bill
 * due on `from` itself resolves to `from` (due today).
 */
export function getNextBillingDate(
  billingDay: number,
  from: Date = new Date(),
): Date {
  const start = startOfDay(from);
  const year = start.getFullYear();
  const month = start.getMonth();

  const candidate = new Date(
    year,
    month,
    clampBillingDay(year, month, billingDay),
  );

  if (candidate.getTime() >= start.getTime()) {
    return candidate;
  }

  const nextMonth = month + 1;
  const nextMonthIndex = nextMonth % 12;
  const nextYear = nextMonth === 12 ? year + 1 : year;

  return new Date(
    nextYear,
    nextMonthIndex,
    clampBillingDay(nextYear, nextMonthIndex, billingDay),
  );
}

export function daysUntilNextBilling(
  billingDay: number,
  from: Date = new Date(),
): number {
  const next = getNextBillingDate(billingDay, from);
  const start = startOfDay(from);
  return Math.round((next.getTime() - start.getTime()) / MS_PER_DAY);
}

/**
 * The billing date that immediately precedes `from` for a recurring bill
 * with `billingDay`. Used to delimit a billing cycle window for
 * de-duplicating alerts (a cycle spans [previousBilling, nextBilling)).
 */
export function getPreviousBillingDate(
  billingDay: number,
  from: Date = new Date(),
): Date {
  const next = getNextBillingDate(billingDay, from);
  const year = next.getFullYear();
  const prevMonth = next.getMonth() - 1;
  const prevYear = prevMonth < 0 ? year - 1 : year;
  const prevMonthIndex = ((prevMonth % 12) + 12) % 12;

  return new Date(
    prevYear,
    prevMonthIndex,
    clampBillingDay(prevYear, prevMonthIndex, billingDay),
  );
}