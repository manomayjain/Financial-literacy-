import express, { Express, Request, Response, Router } from "express";
import cors from "cors";
import { env } from "./config/env";
import {
  errorHandler,
  notFoundHandler,
} from "./middleware/error.middleware";
import { prisma } from "./lib/prisma";
import authRoutes from "./modules/auth/auth.routes";
import ledgerRoutes from "./modules/ledger/ledger.routes";
import goalsRoutes from "./modules/goals/goals.routes";
import subscriptionsRoutes from "./modules/subscriptions/subscriptions.routes";
import alertsRoutes from "./modules/alerts/alerts.routes";
import articlesRoutes from "./modules/articles/articles.routes";
import quizzesRoutes from "./modules/quizzes/quizzes.routes";
import usersRoutes from "./modules/users/users.routes";

export function createApp(): Express {
  const app: Express = express();

  app.use(
    cors({
      origin(origin, callback) {
        // Native mobile apps (Expo/React Native), CLI tools and server-to-server
        // calls send no Origin header — always allow them.
        if (!origin || origin === "null") {
          callback(null, true);
          return;
        }
        // Browser origins (Expo web) must be in the allow-list. CLIENT_URL may
        // be a comma-separated list, e.g. http://localhost:8081,https://app.example.com
        const allowed = env.CLIENT_URL.split(",")
          .map((value) => value.trim().toLowerCase())
          .filter(Boolean);
        const isLocalDevelopmentOrigin =
          env.NODE_ENV !== "production" &&
          /^https?:\/\/(localhost|127\.0\.0\.1|\d{1,3}(?:\.\d{1,3}){3}):\d+$/.test(
            origin,
          );
        if (
          (allowed.length > 0 && allowed.includes(origin.toLowerCase())) ||
          isLocalDevelopmentOrigin
        ) {
          callback(null, true);
          return;
        }
        callback(null, false);
      },
      credentials: true,
    }),
  );
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: true }));

  const healthHandler = async (_req: Request, res: Response): Promise<void> => {
    try {
      await prisma.$queryRaw`SELECT 1`;
      res.json({
        success: true,
        data: {
          status: "ok",
          database: "connected",
          timestamp: new Date().toISOString(),
        },
        error: null,
      });
    } catch (error) {
      console.error("Health check DB failure:", error);
      res.status(503).json({
        success: false,
        data: null,
        error: {
          message: "Database connection failed",
          code: "DB_UNAVAILABLE",
        },
      });
    }
  };

  app.get("/", healthHandler);

  const healthRouter = Router();
  healthRouter.get("/health", healthHandler);
  app.use("/api/v1", healthRouter);
  app.use("/api/v1/auth", authRoutes);
  app.use("/api/v1/ledger", ledgerRoutes);
  app.use("/api/v1/goals", goalsRoutes);
  app.use("/api/v1/subscriptions", subscriptionsRoutes);
  app.use("/api/v1/alerts", alertsRoutes);
  app.use("/api/v1/articles", articlesRoutes);
  app.use("/api/v1/quizzes", quizzesRoutes);
  app.use("/api/v1/users", usersRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
