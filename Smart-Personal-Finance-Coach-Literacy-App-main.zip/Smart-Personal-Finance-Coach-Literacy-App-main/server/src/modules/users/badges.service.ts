import { prisma } from "../../lib/prisma";
import { isPassing } from "../quizzes/quizzes.service";

interface BadgeDefinition {
  id: string;
  name: string;
  description: string;
  metric: "attempts" | "perfect" | "passed";
  needed: number;
}

const BADGE_DEFINITIONS: BadgeDefinition[] = [
  {
    id: "first-quiz",
    name: "First Steps",
    description: "Complete your first quiz.",
    metric: "attempts",
    needed: 1,
  },
  {
    id: "three-quizzes",
    name: "Quiz Rookie",
    description: "Complete 3 quizzes.",
    metric: "attempts",
    needed: 3,
  },
  {
    id: "five-quizzes",
    name: "Quiz Regular",
    description: "Complete 5 quizzes.",
    metric: "attempts",
    needed: 5,
  },
  {
    id: "perfect-score",
    name: "Perfect Score",
    description: "Score 100% on a quiz.",
    metric: "perfect",
    needed: 1,
  },
  {
    id: "five-passed",
    name: "Quiz Pro",
    description: "Pass 5 quizzes with at least two-thirds correct.",
    metric: "passed",
    needed: 5,
  },
];

export interface PublicBadge {
  id: string;
  name: string;
  description: string;
  earned: boolean;
  current: number;
  needed: number;
  progress: number;
}

export async function getBadges(userId: string): Promise<PublicBadge[]> {
  const attempts = await prisma.quizAttempt.findMany({
    where: { userId },
    select: { id: true, quizId: true, score: true },
  });

  let metrics: Record<BadgeDefinition["metric"], number> = {
    attempts: attempts.length,
    perfect: 0,
    passed: 0,
  };

  if (attempts.length > 0) {
    const quizIds = [...new Set(attempts.map((attempt) => attempt.quizId))];
    const quizzes = await prisma.quiz.findMany({
      where: { id: { in: quizIds } },
      select: {
        id: true,
        _count: { select: { questions: true } },
      },
    });
    const totalByQuizId = new Map(
      quizzes.map((quiz) => [quiz.id, quiz._count.questions]),
    );

    for (const attempt of attempts) {
      const total = totalByQuizId.get(attempt.quizId) ?? 0;
      if (total > 0 && attempt.score === total) {
        metrics.perfect++;
      }
      if (isPassing(attempt.score, total)) {
        metrics.passed++;
      }
    }
  }

  return BADGE_DEFINITIONS.map((badge) => {
    const current = metrics[badge.metric];
    return {
      id: badge.id,
      name: badge.name,
      description: badge.description,
      earned: current >= badge.needed,
      current,
      needed: badge.needed,
      progress: Math.min(1, current / badge.needed),
    };
  });
}