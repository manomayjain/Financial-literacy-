import { NextFunction, Request, Response } from "express";
import { success } from "../../utils/apiResponse";
import { AppError } from "../../middleware/error.middleware";
import { getBadges } from "./badges.service";

function requireUserId(req: Request): string {
  if (!req.user?.userId) {
    throw new AppError(401, "Authentication required", "UNAUTHORIZED");
  }
  return req.user.userId;
}

export async function getBadgesHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const badges = await getBadges(requireUserId(req));
    res.json(success({ badges }));
  } catch (error) {
    next(error);
  }
}