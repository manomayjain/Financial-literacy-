import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
import { getBadgesHandler } from "./badges.controller";

const router = Router();

router.use(authenticate);

router.get("/me/badges", getBadgesHandler);

export default router;