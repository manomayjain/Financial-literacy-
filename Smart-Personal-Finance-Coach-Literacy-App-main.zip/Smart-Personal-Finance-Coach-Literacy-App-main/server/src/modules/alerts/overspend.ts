import { prisma } from "../../lib/prisma";

export const CATEGORY_THRESHOLDS: Record<string, number> = {
  Groceries: 600,
  Dining: 400,
  Transport: 300,
  Entertainment: 250,
  Shopping: 400,
  Subscriptions: 200,
  Utilities: 300,
  Health: 500,
  Education: 400,
  Travel: 700,
  Housing: 2000,
  Other: 500,
};

export const DEFAULT_CATEGORY_THRESHOLD = 400;

export function thresholdForCategory(category: string): number {
  return CATEGORY_THRESHOLDS[category] ?? DEFAULT_CATEGORY_THRESHOLD;
}

export function monthStartOf(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

export function nextMonthStart(monthStart: Date): Date {
  return new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 1);
}

export function formatUsd(amount: number): string {
  return amount.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
  });
}

export function buildOverspendMessage(
  category: string,
  spent: number,
  threshold: number,
): string {
  return `[${category}] You've spent ${formatUsd(spent)} on ${category} this month — over your ${formatUsd(threshold)} budget.`;
}

/**
 * Runs after a new ledger entry is created. If the user's EXPENSE total for
 * the entry's category in the month of the entry's date exceeds the
 * per-category threshold, creates an OVERSPEND alert linked to a matching
 * article (by tag) when one exists. De-duplicated per category + month.
 * Failures are logged and swallowed so entry creation is never blocked.
 */
export async function runOverspendCheck(
  userId: string,
  type: "INCOME" | "EXPENSE",
  category: string,
  date: Date,
): Promise<void> {
  try {
    if (type !== "EXPENSE") return;

    const monthStart = monthStartOf(date);
    const monthEnd = nextMonthStart(monthStart);

    const agg = await prisma.entry.aggregate({
      _sum: { amount: true },
      where: {
        userId,
        type: "EXPENSE",
        category,
        date: { gte: monthStart, lt: monthEnd },
      },
    });

    const spent = agg._sum.amount ?? 0;
    const threshold = thresholdForCategory(category);
    if (spent <= threshold) return;

    const existing = await prisma.alert.findFirst({
      where: {
        userId,
        type: "OVERSPEND",
        message: { startsWith: `[${category}]` },
        createdAt: { gte: monthStart },
      },
      select: { id: true },
    });
    if (existing) return;

    const article = await prisma.article.findFirst({
      where: { tag: { equals: category, mode: "insensitive" } },
      select: { id: true },
    });

    await prisma.alert.create({
      data: {
        userId,
        type: "OVERSPEND",
        message: buildOverspendMessage(category, spent, threshold),
        articleId: article?.id ?? null,
      },
    });
  } catch (error) {
    console.error("Overspend alert check failed:", error);
  }
}