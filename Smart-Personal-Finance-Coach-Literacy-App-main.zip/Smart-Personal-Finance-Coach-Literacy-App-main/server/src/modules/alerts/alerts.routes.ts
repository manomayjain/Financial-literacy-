import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
import {
  listAlertsHandler,
  markAlertReadHandler,
  markAllAlertsReadHandler,
} from "./alerts.controller";

const router = Router();

router.use(authenticate);

router.get("/", listAlertsHandler);
router.patch("/read-all", markAllAlertsReadHandler);
router.patch("/:id/read", markAlertReadHandler);

export default router;