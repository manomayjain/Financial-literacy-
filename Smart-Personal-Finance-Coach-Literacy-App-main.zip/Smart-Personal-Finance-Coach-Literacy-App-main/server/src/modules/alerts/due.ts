import { prisma } from "../../lib/prisma";
import {
  daysUntilNextBilling,
  getPreviousBillingDate,
} from "../../utils/billing";
import { formatUsd } from "./overspend";

/**
 * Scans the user's active subscriptions and creates a SUBSCRIPTION_DUE alert
 * for anything billing within the next 3 days. De-duplicated per subscription
 * and billing cycle (a cycle spans the previous billing date through the next
 * one), so re-fetching alerts never spams duplicates.
 */
export async function runSubscriptionDueCheck(userId: string): Promise<void> {
  try {
    const subscriptions = await prisma.subscription.findMany({
      where: { userId, active: true },
      select: { id: true, name: true, amount: true, billingDay: true },
    });

    for (const subscription of subscriptions) {
      const days = daysUntilNextBilling(subscription.billingDay);
      if (days < 0 || days > 3) continue;

      const cycleStart = getPreviousBillingDate(subscription.billingDay);

      const existing = await prisma.alert.findFirst({
        where: {
          userId,
          type: "SUBSCRIPTION_DUE",
          message: { startsWith: `[${subscription.name}]` },
          createdAt: { gte: cycleStart },
        },
        select: { id: true },
      });
      if (existing) continue;

      const dueLabel =
        days === 0 ? "today" : days === 1 ? "tomorrow" : `in ${days} days`;

      await prisma.alert.create({
        data: {
          userId,
          type: "SUBSCRIPTION_DUE",
          message: `[${subscription.name}] ${subscription.name} bills ${dueLabel} — ${formatUsd(subscription.amount)}/mo.`,
        },
      });
    }
  } catch (error) {
    console.error("Subscription due alert check failed:", error);
  }
}