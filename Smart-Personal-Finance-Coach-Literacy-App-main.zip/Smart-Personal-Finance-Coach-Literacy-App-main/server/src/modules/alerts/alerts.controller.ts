import { NextFunction, Request, Response } from "express";
import { success } from "../../utils/apiResponse";
import { AppError } from "../../middleware/error.middleware";
import * as alertsService from "./alerts.service";

function requireUserId(req: Request): string {
  if (!req.user?.userId) {
    throw new AppError(401, "Authentication required", "UNAUTHORIZED");
  }
  return req.user.userId;
}

export async function listAlertsHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const result = await alertsService.listAlerts(requireUserId(req));
    res.json(success(result));
  } catch (error) {
    next(error);
  }
}

export async function markAlertReadHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const alert = await alertsService.markAlertRead(
      requireUserId(req),
      req.params.id,
    );
    res.json(success({ alert }));
  } catch (error) {
    next(error);
  }
}

export async function markAllAlertsReadHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const result = await alertsService.markAllAlertsRead(requireUserId(req));
    res.json(success(result));
  } catch (error) {
    next(error);
  }
}