import { Prisma } from "@prisma/client";
import { prisma } from "../../lib/prisma";
import { AppError } from "../../middleware/error.middleware";
import { runSubscriptionDueCheck } from "./due";

const alertSelect = {
  id: true,
  type: true,
  message: true,
  isRead: true,
  articleId: true,
  createdAt: true,
  article: { select: { id: true, title: true } },
} satisfies Prisma.AlertSelect;

type RawAlert = Prisma.AlertGetPayload<{ select: typeof alertSelect }>;

export interface PublicAlert {
  id: string;
  type: "OVERSPEND" | "SUBSCRIPTION_DUE";
  message: string;
  isRead: boolean;
  articleId: string | null;
  createdAt: string;
  article: { id: string; title: string } | null;
}

function toPublicAlert(alert: RawAlert): PublicAlert {
  return {
    id: alert.id,
    type: alert.type,
    message: alert.message,
    isRead: alert.isRead,
    articleId: alert.articleId,
    createdAt: alert.createdAt.toISOString(),
    article: alert.article
      ? { id: alert.article.id, title: alert.article.title }
      : null,
  };
}

export interface AlertListResult {
  alerts: PublicAlert[];
  unreadCount: number;
}

export async function listAlerts(userId: string): Promise<AlertListResult> {
  await runSubscriptionDueCheck(userId);

  const alerts = await prisma.alert.findMany({
    where: { userId },
    orderBy: [{ isRead: "asc" }, { createdAt: "desc" }],
    select: alertSelect,
  });

  return {
    alerts: alerts.map(toPublicAlert),
    unreadCount: alerts.filter((alert) => !alert.isRead).length,
  };
}

async function findOwnedAlert(userId: string, id: string): Promise<RawAlert> {
  const alert = await prisma.alert.findFirst({
    where: { id, userId },
    select: alertSelect,
  });
  if (!alert) {
    throw new AppError(404, "Alert not found", "ALERT_NOT_FOUND");
  }
  return alert;
}

export async function markAlertRead(userId: string, id: string) {
  await findOwnedAlert(userId, id);

  const alert = await prisma.alert.update({
    where: { id },
    data: { isRead: true },
    select: alertSelect,
  });

  return toPublicAlert(alert);
}

export async function markAllAlertsRead(userId: string) {
  const result = await prisma.alert.updateMany({
    where: { userId, isRead: false },
    data: { isRead: true },
  });
  return { count: result.count };
}