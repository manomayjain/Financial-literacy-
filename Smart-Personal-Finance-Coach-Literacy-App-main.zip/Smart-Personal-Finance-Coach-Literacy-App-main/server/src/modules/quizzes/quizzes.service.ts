import { prisma } from "../../lib/prisma";
import { AppError } from "../../middleware/error.middleware";
import type { QuizAttemptInput } from "./quizzes.schema";

export interface PublicAttempt {
  id: string;
  score: number;
  total: number;
  passed: boolean;
  createdAt: string;
}

const PASS_RATIO = 2 / 3;

export function isPassing(score: number, total: number): boolean {
  if (total <= 0) return false;
  return score / total >= PASS_RATIO;
}

export async function submitAttempt(
  userId: string,
  quizId: string,
  input: QuizAttemptInput,
): Promise<PublicAttempt> {
  const quiz = await prisma.quiz.findUnique({
    where: { id: quizId },
    select: {
      id: true,
      questions: {
        select: { id: true, correctIndex: true, options: true },
        orderBy: { id: "asc" },
      },
    },
  });

  if (!quiz) {
    throw new AppError(404, "Quiz not found", "QUIZ_NOT_FOUND");
  }

  if (input.answers.length !== quiz.questions.length) {
    throw new AppError(
      400,
      `This quiz has ${quiz.questions.length} questions, but ${input.answers.length} answers were given.`,
      "QUIZ_ANSWERS_MISMATCH",
    );
  }

  if (quiz.questions.length === 0) {
    throw new AppError(400, "This quiz has no questions", "QUIZ_EMPTY");
  }

  for (let i = 0; i < quiz.questions.length; i++) {
    const answer = input.answers[i];
    if (!Number.isInteger(answer)) {
      throw new AppError(400, "Answer must be a whole number", "INVALID_ANSWER");
    }
    if (answer < 0 || answer >= quiz.questions[i].options.length) {
      throw new AppError(
        400,
        `Answer ${answer} is not a valid option for question ${i + 1}.`,
        "INVALID_ANSWER",
      );
    }
  }

  let score = 0;
  for (let i = 0; i < quiz.questions.length; i++) {
    if (quiz.questions[i].correctIndex === input.answers[i]) {
      score++;
    }
  }
  const total = quiz.questions.length;

  const attempt = await prisma.quizAttempt.create({
    data: {
      userId,
      quizId,
      score,
    },
    select: { id: true, score: true, createdAt: true },
  });

  return {
    id: attempt.id,
    score,
    total,
    passed: isPassing(score, total),
    createdAt: attempt.createdAt.toISOString(),
  };
}