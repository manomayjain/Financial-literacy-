import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
import { validate } from "../../middleware/validate.middleware";
import { quizAttemptSchema } from "./quizzes.schema";
import { submitAttemptHandler } from "./quizzes.controller";

const router = Router();

router.use(authenticate);

router.post("/:id/attempt", validate(quizAttemptSchema), submitAttemptHandler);

export default router;