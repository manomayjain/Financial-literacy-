import { z } from "zod";

export const quizAttemptSchema = z.object({
  answers: z
    .array(z.number().int("Answer index must be a whole number").min(0, "Answer index can't be negative"))
    .min(1, "At least one answer is required")
    .max(50, "Too many answers"),
});

export type QuizAttemptInput = z.infer<typeof quizAttemptSchema>;