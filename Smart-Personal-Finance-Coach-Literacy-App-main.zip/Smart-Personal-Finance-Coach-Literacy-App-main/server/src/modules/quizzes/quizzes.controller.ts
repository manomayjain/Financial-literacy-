import { NextFunction, Request, Response } from "express";
import { success } from "../../utils/apiResponse";
import { AppError } from "../../middleware/error.middleware";
import { submitAttempt } from "./quizzes.service";

function requireUserId(req: Request): string {
  if (!req.user?.userId) {
    throw new AppError(401, "Authentication required", "UNAUTHORIZED");
  }
  return req.user.userId;
}

export async function submitAttemptHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const attempt = await submitAttempt(
      requireUserId(req),
      req.params.id,
      req.body,
    );
    res.json(success({ attempt }));
  } catch (error) {
    next(error);
  }
}