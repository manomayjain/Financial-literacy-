import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
import { validate } from "../../middleware/validate.middleware";
import {
  createSubscriptionSchema,
  updateSubscriptionSchema,
} from "./subscriptions.schema";
import {
  createSubscriptionHandler,
  listSubscriptionsHandler,
  updateSubscriptionHandler,
  deleteSubscriptionHandler,
} from "./subscriptions.controller";

const router = Router();

router.use(authenticate);

router.post(
  "/",
  validate(createSubscriptionSchema),
  createSubscriptionHandler,
);
router.get("/", listSubscriptionsHandler);
router.patch(
  "/:id",
  validate(updateSubscriptionSchema),
  updateSubscriptionHandler,
);
router.delete("/:id", deleteSubscriptionHandler);

export default router;