import { Prisma } from "@prisma/client";
import { prisma } from "../../lib/prisma";
import { AppError } from "../../middleware/error.middleware";
import {
  daysUntilNextBilling,
  getNextBillingDate,
} from "../../utils/billing";
import type {
  CreateSubscriptionInput,
  UpdateSubscriptionInput,
} from "./subscriptions.schema";

const subscriptionSelect = {
  id: true,
  name: true,
  amount: true,
  billingDay: true,
  active: true,
} satisfies Prisma.SubscriptionSelect;

type RawSubscription = Prisma.SubscriptionGetPayload<{
  select: typeof subscriptionSelect;
}>;

export interface PublicSubscription {
  id: string;
  name: string;
  amount: number;
  billingDay: number;
  active: boolean;
  nextBillingDate: string | null;
  daysUntilNextBilling: number | null;
}

function toPublicSubscription(subscription: RawSubscription): PublicSubscription {
  const base = {
    id: subscription.id,
    name: subscription.name,
    amount: subscription.amount,
    billingDay: subscription.billingDay,
    active: subscription.active,
  };

  if (!subscription.active) {
    return {
      ...base,
      nextBillingDate: null,
      daysUntilNextBilling: null,
    };
  }

  return {
    ...base,
    nextBillingDate: getNextBillingDate(subscription.billingDay).toISOString(),
    daysUntilNextBilling: daysUntilNextBilling(subscription.billingDay),
  };
}

async function hasDuplicateName(
  userId: string,
  name: string,
  excludeId?: string,
): Promise<boolean> {
  const existing = await prisma.subscription.findFirst({
    where: {
      userId,
      ...(excludeId ? { id: { not: excludeId } } : {}),
      name: { equals: name, mode: "insensitive" },
    },
    select: { id: true },
  });
  return Boolean(existing);
}

export async function createSubscription(
  userId: string,
  input: CreateSubscriptionInput,
): Promise<{ subscription: PublicSubscription; warnings: string[] }> {
  const isDuplicate = await hasDuplicateName(userId, input.name);

  const subscription = await prisma.subscription.create({
    data: {
      userId,
      name: input.name,
      amount: input.amount,
      billingDay: input.billingDay,
    },
    select: subscriptionSelect,
  });

  const warnings = isDuplicate
    ? [`"${input.name}" is already on your list.`]
    : [];

  return { subscription: toPublicSubscription(subscription), warnings };
}

export async function listSubscriptions(
  userId: string,
): Promise<PublicSubscription[]> {
  const subscriptions = await prisma.subscription.findMany({
    where: { userId },
    orderBy: { name: "asc" },
    select: subscriptionSelect,
  });

  return subscriptions
    .map(toPublicSubscription)
    .sort((a, b) => {
      if (a.active !== b.active) return a.active ? -1 : 1;
      return (a.daysUntilNextBilling ?? Number.POSITIVE_INFINITY) -
        (b.daysUntilNextBilling ?? Number.POSITIVE_INFINITY);
    });
}

async function findOwnedSubscription(userId: string, id: string) {
  const subscription = await prisma.subscription.findFirst({
    where: { id, userId },
    select: subscriptionSelect,
  });
  if (!subscription) {
    throw new AppError(404, "Subscription not found", "SUBSCRIPTION_NOT_FOUND");
  }
  return subscription;
}

export async function updateSubscription(
  userId: string,
  id: string,
  input: UpdateSubscriptionInput,
): Promise<{ subscription: PublicSubscription; warnings: string[] }> {
  await findOwnedSubscription(userId, id);

  let warnings: string[] = [];
  if (input.name !== undefined) {
    const isDuplicate = await hasDuplicateName(userId, input.name, id);
    if (isDuplicate) {
      warnings = [`"${input.name}" is already on your list.`];
    }
  }

  const subscription = await prisma.subscription.update({
    where: { id },
    data: {
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.amount !== undefined ? { amount: input.amount } : {}),
      ...(input.billingDay !== undefined ? { billingDay: input.billingDay } : {}),
      ...(input.active !== undefined ? { active: input.active } : {}),
    },
    select: subscriptionSelect,
  });

  return { subscription: toPublicSubscription(subscription), warnings };
}

export async function deleteSubscription(userId: string, id: string) {
  await findOwnedSubscription(userId, id);
  await prisma.subscription.delete({ where: { id } });
  return { id };
}