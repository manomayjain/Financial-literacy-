import { NextFunction, Request, Response } from "express";
import { success } from "../../utils/apiResponse";
import { AppError } from "../../middleware/error.middleware";
import * as subscriptionsService from "./subscriptions.service";
import type {
  CreateSubscriptionInput,
  UpdateSubscriptionInput,
} from "./subscriptions.schema";

function requireUserId(req: Request): string {
  if (!req.user?.userId) {
    throw new AppError(401, "Authentication required", "UNAUTHORIZED");
  }
  return req.user.userId;
}

export async function createSubscriptionHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const { subscription, warnings } =
      await subscriptionsService.createSubscription(
        requireUserId(req),
        req.body as CreateSubscriptionInput,
      );
    res.status(201).json(success({ subscription, warnings }));
  } catch (error) {
    next(error);
  }
}

export async function listSubscriptionsHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const subscriptions = await subscriptionsService.listSubscriptions(
      requireUserId(req),
    );
    res.json(success({ subscriptions }));
  } catch (error) {
    next(error);
  }
}

export async function updateSubscriptionHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const { subscription, warnings } =
      await subscriptionsService.updateSubscription(
        requireUserId(req),
        req.params.id,
        req.body as UpdateSubscriptionInput,
      );
    res.json(success({ subscription, warnings }));
  } catch (error) {
    next(error);
  }
}

export async function deleteSubscriptionHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const result = await subscriptionsService.deleteSubscription(
      requireUserId(req),
      req.params.id,
    );
    res.json(success(result));
  } catch (error) {
    next(error);
  }
}