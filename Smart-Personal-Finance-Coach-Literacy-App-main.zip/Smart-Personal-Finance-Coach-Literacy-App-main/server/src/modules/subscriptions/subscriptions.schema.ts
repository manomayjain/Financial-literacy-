import { z } from "zod";

const subscriptionNameSchema = z
  .string({ required_error: "Name is required" })
  .trim()
  .min(1, "Name is required")
  .max(80, "Name must be 80 characters or fewer");

const amountSchema = z
  .number({ invalid_type_error: "Amount must be a number" })
  .positive("Amount must be greater than 0")
  .max(999_999_999, "Amount is too large");

const billingDaySchema = z
  .number({ invalid_type_error: "Billing day must be a number" })
  .int("Billing day must be a whole number")
  .min(1, "Billing day must be between 1 and 31")
  .max(31, "Billing day must be between 1 and 31");

export const createSubscriptionSchema = z.object({
  name: subscriptionNameSchema,
  amount: amountSchema,
  billingDay: billingDaySchema,
});

export const updateSubscriptionSchema = z
  .object({
    name: subscriptionNameSchema.optional(),
    amount: amountSchema.optional(),
    billingDay: billingDaySchema.optional(),
    active: z.boolean().optional(),
  })
  .refine((data) => Object.keys(data).length > 0, {
    message: "At least one field to update is required",
    path: ["subscription"],
  });

export type CreateSubscriptionInput = z.infer<typeof createSubscriptionSchema>;
export type UpdateSubscriptionInput = z.infer<typeof updateSubscriptionSchema>;