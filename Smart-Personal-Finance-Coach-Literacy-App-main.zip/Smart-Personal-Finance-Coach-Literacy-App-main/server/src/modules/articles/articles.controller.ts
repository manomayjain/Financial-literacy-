import { NextFunction, Request, Response } from "express";
import { success } from "../../utils/apiResponse";
import { AppError } from "../../middleware/error.middleware";
import { getArticle, listArticles } from "./articles.service";

function requireUserId(req: Request): string {
  if (!req.user?.userId) {
    throw new AppError(401, "Authentication required", "UNAUTHORIZED");
  }
  return req.user.userId;
}

const KNOWN_TAGS = new Set([
  "food",
  "entertainment",
  "shopping",
  "subscriptions",
  "saving-basics",
  "budgeting-basics",
]);

export async function listArticlesHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    requireUserId(req);
    const tag = typeof req.query.tag === "string" ? req.query.tag : undefined;
    if (tag && !KNOWN_TAGS.has(tag)) {
      throw new AppError(
        400,
        "Unknown tag. Use one of: " + [...KNOWN_TAGS].join(", "),
        "INVALID_TAG",
      );
    }
    const articles = await listArticles(tag);
    res.json(success({ articles }));
  } catch (error) {
    next(error);
  }
}

export async function getArticleHandler(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    requireUserId(req);
    const article = await getArticle(req.params.id);
    res.json(success({ article }));
  } catch (error) {
    next(error);
  }
}