import { Prisma } from "@prisma/client";
import { prisma } from "../../lib/prisma";
import { AppError } from "../../middleware/error.middleware";

const articleSummarySelect = {
  id: true,
  title: true,
  summary: true,
  tag: true,
} satisfies Prisma.ArticleSelect;

const articleDetailSelect = {
  id: true,
  title: true,
  summary: true,
  tag: true,
  body: true,
  quiz: {
    select: {
      id: true,
      questions: {
        select: {
          id: true,
          text: true,
          options: true,
          correctIndex: true,
        },
        orderBy: { id: "asc" as const },
      },
    },
  },
} satisfies Prisma.ArticleSelect;

export interface PublicArticleSummary {
  id: string;
  title: string;
  summary: string;
  tag: string;
}

export interface PublicQuestion {
  id: string;
  text: string;
  options: string[];
  correctIndex: number;
}

export interface PublicArticleDetail extends PublicArticleSummary {
  body: string;
  quiz: {
    id: string;
    questions: PublicQuestion[];
  } | null;
}

export async function listArticles(tag?: string): Promise<PublicArticleSummary[]> {
  const articles = await prisma.article.findMany({
    where: tag ? { tag } : {},
    select: articleSummarySelect,
    orderBy: { title: "asc" },
  });
  return articles;
}

export async function getArticle(id: string): Promise<PublicArticleDetail> {
  const article = await prisma.article.findUnique({
    where: { id },
    select: articleDetailSelect,
  });
  if (!article) {
    throw new AppError(404, "Article not found", "ARTICLE_NOT_FOUND");
  }
  return article;
}