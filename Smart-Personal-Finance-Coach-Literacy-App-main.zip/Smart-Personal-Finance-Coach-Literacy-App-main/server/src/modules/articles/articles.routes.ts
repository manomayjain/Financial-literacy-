import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
import {
  getArticleHandler,
  listArticlesHandler,
} from "./articles.controller";

const router = Router();

router.use(authenticate);

router.get("/", listArticlesHandler);
router.get("/:id", getArticleHandler);

export default router;