import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { Card } from "@/components/ui";
import type { ArticleSummary } from "@/hooks/useArticles";
import { formatTag } from "@/lib/articleTags";

export interface ArticleCardProps {
  article: ArticleSummary;
}

export function ArticleCard({ article }: ArticleCardProps) {
  return (
    <Pressable
      onPress={() => router.push(`/article/${article.id}`)}
      accessibilityRole="button"
      className="mb-3 active:opacity-80"
    >
      <Card className="p-4">
        <View className="mb-2 self-start rounded-full bg-primary/15 px-2.5 py-1">
          <Text className="text-xs font-semibold text-primary">
            {formatTag(article.tag)}
          </Text>
        </View>
        <Text className="text-base font-semibold text-white">
          {article.title}
        </Text>
        <Text className="mt-1 text-sm text-muted">{article.summary}</Text>
        <View className="mt-3 flex-row items-center">
          <Ionicons name="school-outline" size={14} color="#208AEF" />
          <Text className="ml-1 text-xs font-medium text-primary">
            Read + take the quiz
          </Text>
        </View>
      </Card>
    </Pressable>
  );
}