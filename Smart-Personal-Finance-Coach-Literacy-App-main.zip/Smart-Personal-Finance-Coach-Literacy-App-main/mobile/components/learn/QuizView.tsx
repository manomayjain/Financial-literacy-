import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";
import { Button, Card } from "@/components/ui";
import type { ArticleQuiz } from "@/hooks/useArticles";
import {
  useSubmitQuizAttempt,
  type QuizAttemptResult,
} from "@/hooks/useQuizzes";

export interface QuizViewProps {
  quiz: ArticleQuiz;
}

export function QuizView({ quiz }: QuizViewProps) {
  const [runKey, setRunKey] = useState(0);

  const restart = () => setRunKey((key) => key + 1);

  return <QuizRun key={runKey} quiz={quiz} onRestart={restart} />;
}

interface QuizRunProps {
  quiz: ArticleQuiz;
  onRestart: () => void;
}

function QuizRun({ quiz, onRestart }: QuizRunProps) {
  const submit = useSubmitQuizAttempt(quiz.id);
  const [current, setCurrent] = useState(0);
  const [selections, setSelections] = useState<(number | null)[]>(() =>
    quiz.questions.map(() => null),
  );
  const [finished, setFinished] = useState(false);

  const question = quiz.questions[current];
  const selected = selections[current];
  const isLastQuestion = current === quiz.questions.length - 1;

  const choose = (index: number) => {
    if (selected !== null) return;
    setSelections((prev) => {
      const next = [...prev];
      next[current] = index;
      return next;
    });
  };

  const handleNext = () => {
    if (selected === null) return;
    if (isLastQuestion) {
      setFinished(true);
      submit.mutate(selections as number[]);
    } else {
      setCurrent((value) => value + 1);
    }
  };

  if (finished) {
    return (
      <ResultsView
        result={submit.data}
        isPending={submit.isPending}
        isError={submit.isError}
        onRetry={() => submit.mutate(selections as number[])}
        onRestart={onRestart}
      />
    );
  }

  return (
    <View className="mt-4">
      <Text className="text-xs font-semibold uppercase tracking-wide text-muted">
        Quick quiz · {current + 1} of {quiz.questions.length}
      </Text>
      <Text className="mt-2 text-lg font-semibold text-white">
        {question.text}
      </Text>

      <View className="mt-4">
        {question.options.map((option, index) => (
          <OptionButton
            key={option}
            label={option}
            index={index}
            correctIndex={question.correctIndex}
            selected={selected}
            onPress={() => choose(index)}
          />
        ))}
      </View>

      {selected !== null ? (
        <Text
          className={[
            "mt-2 text-sm font-medium",
            selected === question.correctIndex ? "text-success" : "text-danger",
          ].join(" ")}
        >
          {selected === question.correctIndex
            ? "Correct!"
            : "Not quite — the right answer is highlighted above."}
        </Text>
      ) : null}

      <Button
        title={isLastQuestion ? "See results" : "Next"}
        fullWidth
        disabled={selected === null}
        onPress={handleNext}
        className="mt-4"
      />
    </View>
  );
}

interface OptionButtonProps {
  label: string;
  index: number;
  correctIndex: number;
  selected: number | null;
  onPress: () => void;
}

function OptionButton({
  label,
  index,
  correctIndex,
  selected,
  onPress,
}: OptionButtonProps) {
  const isCorrect = index === correctIndex;
  const isSelected = selected === index;
  const answered = selected !== null;

  let container = "border-border bg-surface";
  let icon: React.ReactNode = null;

  if (answered) {
    if (isCorrect) {
      container = "border-success bg-success/15";
      icon = <Ionicons name="checkmark-circle" size={20} color="#22C55E" />;
    } else if (isSelected) {
      container = "border-danger bg-danger/15";
      icon = <Ionicons name="close-circle" size={20} color="#EF4444" />;
    }
  }

  return (
    <Pressable
      onPress={onPress}
      disabled={answered}
      accessibilityRole="button"
      className={["mb-2.5 flex-row items-center rounded-lg border p-3.5", container].join(" ")}
    >
      <Text className="flex-1 text-sm text-white">{label}</Text>
      {icon}
    </Pressable>
  );
}

interface ResultsViewProps {
  result: QuizAttemptResult | undefined;
  isPending: boolean;
  isError: boolean;
  onRetry: () => void;
  onRestart: () => void;
}

function ResultsView({
  result,
  isPending,
  isError,
  onRetry,
  onRestart,
}: ResultsViewProps) {
  if (isPending) {
    return (
      <View className="items-center py-10">
        <ActivityIndicator color="#208AEF" size="large" />
        <Text className="mt-3 text-sm text-muted">Grading your answers…</Text>
      </View>
    );
  }

  if (isError) {
    return (
      <View className="items-center py-8">
        <Text className="text-center text-base font-semibold text-white">
          We could not save your results.
        </Text>
        <Button title="Try again" onPress={onRetry} style={{ marginTop: 16 }} />
      </View>
    );
  }

  if (!result) return null;

  const percent = Math.round((result.score / result.total) * 100);

  return (
    <Card className="mt-4 items-center p-6">
      <Text className="text-sm text-muted">Your score</Text>
      <Text className="mt-1 text-4xl font-bold text-white">
        {result.score}
        <Text className="text-xl font-semibold text-muted">
          {" "}/ {result.total}
        </Text>
      </Text>
      <Text className="mt-1 text-sm font-medium text-muted">{percent}%</Text>

      <View
        className={[
          "mt-3 flex-row items-center rounded-full px-3 py-1.5",
          result.passed ? "bg-success/20" : "bg-warning/20",
        ].join(" ")}
      >
        <Ionicons
          name={result.passed ? "trophy" : "refresh"}
          size={14}
          color={result.passed ? "#22C55E" : "#D97706"}
        />
        <Text
          className={[
            "ml-1.5 text-xs font-semibold",
            result.passed ? "text-success" : "text-warning",
          ].join(" ")}
        >
          {result.passed ? "Quiz passed" : "Keep practicing"}
        </Text>
      </View>

      <Button
        title="Retake quiz"
        variant="outline"
        onPress={onRestart}
        style={{ marginTop: 20 }}
      />
    </Card>
  );
}
