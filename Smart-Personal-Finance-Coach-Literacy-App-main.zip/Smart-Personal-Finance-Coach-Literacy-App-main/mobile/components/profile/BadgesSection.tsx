import { Ionicons } from "@expo/vector-icons";
import { Text, View } from "react-native";
import { Card, ErrorState, Skeleton } from "@/components/ui";
import { useBadges } from "@/hooks/useQuizzes";

export function BadgesSection() {
  const badges = useBadges();

  return (
    <Card className="mb-6">
      <View className="mb-3 flex-row items-center justify-between">
        <Text className="text-base font-semibold text-white">Badges</Text>
        <Ionicons name="ribbon" size={20} color="#D97706" />
      </View>

      {badges.isLoading ? (
        <View>
          <Skeleton height={44} className="mb-3" />
          <Skeleton height={44} className="mb-3" />
          <Skeleton height={44} />
        </View>
      ) : badges.isError ? (
        <ErrorState
          message="Couldn't load badges."
          onRetry={() => void badges.refetch()}
          style={{ paddingVertical: 12 }}
        />
      ) : (
        (badges.data ?? []).map((badge) => {
          const earned = badge.earned;
          return (
            <View
              key={badge.id}
              className="mb-3 flex-row items-center border-b border-border pb-3 last:mb-0 last:border-b-0 last:pb-0"
            >
              <View
                className={[
                  "h-10 w-10 items-center justify-center rounded-full",
                  earned ? "bg-success/20" : "bg-surface",
                ].join(" ")}
              >
                <Ionicons
                  name={earned ? "ribbon" : "ribbon-outline"}
                  size={20}
                  color={earned ? "#22C55E" : "#475569"}
                />
              </View>
              <View className="mx-3 flex-1">
                <Text
                  className={[
                    "text-sm font-semibold",
                    earned ? "text-white" : "text-muted",
                  ].join(" ")}
                >
                  {badge.name}
                </Text>
                <Text className="text-xs text-muted">{badge.description}</Text>
              </View>
              <Text
                className={[
                  "text-sm font-medium",
                  earned ? "text-success" : "text-muted",
                ].join(" ")}
              >
                {badge.current}/{badge.needed}
              </Text>
            </View>
          );
        })
      )}
    </Card>
  );
}