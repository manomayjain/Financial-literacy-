import { Ionicons } from "@expo/vector-icons";
import { Pressable, Switch, Text, View } from "react-native";
import { Button, Card } from "@/components/ui";
import { DueBadge } from "./DueBadge";
import type { Subscription } from "@/hooks/useSubscriptions";
import { formatBillingDay, formatCurrency } from "@/lib/format";

export interface SubscriptionRowProps {
  subscription: Subscription;
  onEdit: () => void;
  onDelete: () => void;
  onToggle: (active: boolean) => void;
  pending?: boolean;
}

export function SubscriptionRow({
  subscription,
  onEdit,
  onDelete,
  onToggle,
  pending = false,
}: SubscriptionRowProps) {
  const { name, amount, billingDay, active } = subscription;

  return (
    <Card padded={false} className="mb-3">
      <View className="flex-row items-center">
        <Pressable
          onPress={onEdit}
          className="flex-1 flex-row items-center px-4 py-3 active:bg-slate-800"
          accessibilityRole="button"
        >
          <View className="mr-3 h-10 w-10 items-center justify-center rounded-full bg-primary/15">
            <Ionicons name="card-outline" size={20} color="#208AEF" />
          </View>

          <View className="mr-2 flex-1">
            <View className="mb-1 flex-row items-center gap-2">
              <Text
                className="max-w-[60%] text-base font-medium text-white"
                numberOfLines={1}
              >
                {name}
              </Text>
              <DueBadge
                daysUntilNextBilling={subscription.daysUntilNextBilling}
                active={active}
              />
            </View>
            <Text className="text-sm text-muted">
              {formatCurrency(amount)}/mo · Bills on the {formatBillingDay(billingDay)}
            </Text>
          </View>
        </Pressable>

        <View className="pr-4">
          <Switch
            value={active}
            onValueChange={onToggle}
            disabled={pending}
            trackColor={{ false: "#334155", true: "#1B76CC" }}
            thumbColor={active ? "#FFFFFF" : "#94A3B8"}
            accessibilityLabel={`${active ? "Deactivate" : "Activate"} ${name}`}
          />
        </View>
      </View>

      <View className="flex-row items-center justify-end gap-2 border-t border-border px-3 py-2">
        <Button
          title="Edit"
          variant="outline"
          size="sm"
          leftIcon={<Ionicons name="create-outline" size={15} color="#208AEF" />}
          onPress={onEdit}
        />
        <Button
          title="Delete"
          variant="secondary"
          size="sm"
          leftIcon={<Ionicons name="trash-outline" size={15} color="#94A3B8" />}
          onPress={onDelete}
        />
      </View>
    </Card>
  );
}
