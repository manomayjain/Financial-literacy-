import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { z } from "zod";
import { Ionicons } from "@expo/vector-icons";
import { Banner, Button, Input } from "@/components/ui";
import {
  useCreateSubscription,
  useUpdateSubscription,
  type Subscription,
} from "@/hooks/useSubscriptions";
import { getErrorIssues } from "@/lib/api";

const subscriptionFormSchema = z.object({
  name: z
    .string()
    .min(1, "Name is required")
    .max(80, "Name must be 80 characters or fewer"),
  amount: z
    .string()
    .min(1, "Enter the monthly amount")
    .refine((value) => {
      const number = Number(value);
      return Number.isFinite(number) && number > 0;
    }, "Amount must be greater than 0")
    .refine((value) => Number(value) <= 999_999_999, "Amount is too large"),
  billingDay: z
    .string()
    .min(1, "Enter the billing day")
    .refine((value) => {
      const number = Number(value);
      return (
        /^\d{1,2}$/.test(value) &&
        Number.isInteger(number) &&
        number >= 1 &&
        number <= 31
      );
    }, "Billing day must be a whole number from 1 to 31"),
});

type SubscriptionFormValues = z.infer<typeof subscriptionFormSchema>;

export interface SubscriptionFormProps {
  visible: boolean;
  initialValues?: Subscription | null;
  isOffline?: boolean;
  onClose: () => void;
}

export function SubscriptionForm({
  visible,
  initialValues,
  isOffline = false,
  onClose,
}: SubscriptionFormProps) {
  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      {visible ? (
        <SubscriptionFormBody
          key={initialValues?.id ?? "create"}
          initialValues={initialValues ?? null}
          isOffline={isOffline}
          onClose={onClose}
        />
      ) : null}
    </Modal>
  );
}

function SubscriptionFormBody({
  initialValues,
  isOffline,
  onClose,
}: {
  initialValues: Subscription | null;
  isOffline: boolean;
  onClose: () => void;
}) {
  const createSubscription = useCreateSubscription();
  const updateSubscription = useUpdateSubscription();

  const isEditing = Boolean(initialValues?.id);
  const editingId = initialValues?.id;

  const {
    control,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SubscriptionFormValues>({
    resolver: zodResolver(subscriptionFormSchema),
    defaultValues: initialValues
      ? {
          name: initialValues.name,
          amount: String(initialValues.amount),
          billingDay: String(initialValues.billingDay),
        }
      : { name: "", amount: "", billingDay: "" },
  });

  const isPending =
    createSubscription.isPending || updateSubscription.isPending;

  const onSubmit = (values: SubscriptionFormValues) => {
    const payload = {
      name: values.name,
      amount: Number(values.amount),
      billingDay: Number(values.billingDay),
    };

    const handleServerIssues = (error: unknown) => {
      const issues = getErrorIssues(error);
      if (issues) {
        for (const [field, messages] of Object.entries(issues)) {
          setError(field as keyof SubscriptionFormValues, {
            message: messages[0],
          });
        }
      }
    };

    if (editingId) {
      updateSubscription.mutate(
        { id: editingId, input: payload },
        { onSuccess: onClose, onError: handleServerIssues },
      );
    } else {
      createSubscription.mutate(payload, {
        onSuccess: onClose,
        onError: handleServerIssues,
      });
    }
  };

  return (
    <View className="flex-1 bg-background">
      <View className="flex-row items-center border-b border-border px-5 pb-4 pt-5">
        <View className="mr-3 h-11 w-11 items-center justify-center rounded-2xl bg-primary/15">
          <Ionicons name="card-outline" size={22} color="#208AEF" />
        </View>
        <View className="flex-1">
          <Text className="text-xl font-bold text-white">
            {isEditing ? "Edit subscription" : "Add subscription"}
          </Text>
          <Text className="mt-0.5 text-sm text-muted">
            Keep recurring spending under control.
          </Text>
        </View>
        <Pressable
          onPress={onClose}
          hitSlop={10}
          className="h-9 w-9 items-center justify-center rounded-full bg-surface"
        >
          <Ionicons name="close" size={20} color="#94A3B8" />
        </Pressable>
      </View>

      {isOffline ? (
        <View className="px-4 pt-3">
          <Banner
            message="You're offline. Subscriptions can't be saved right now."
            variant="warning"
          />
        </View>
      ) : null}

      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}
      >
        <ScrollView
          className="flex-1 px-4"
          contentContainerStyle={{ paddingBottom: 160 }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
        >
          <View className="mt-5 rounded-2xl border border-border bg-surface p-4">
            <Controller
              control={control}
              name="name"
              render={({ field: { onChange, onBlur, value } }) => (
                <Input
                  label="Name"
                  placeholder="e.g. Netflix"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.name?.message}
                  className=""
                />
              )}
            />

            <Controller
              control={control}
              name="amount"
              render={({ field: { onChange, onBlur, value } }) => (
                <Input
                  label="Monthly amount"
                  placeholder="0.00"
                  keyboardType="decimal-pad"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.amount?.message}
                  className=""
                />
              )}
            />

            <Controller
              control={control}
              name="billingDay"
              render={({ field: { onChange, onBlur, value } }) => (
                <Input
                  label="Billing day (1-31)"
                  placeholder="e.g. 5"
                  keyboardType="number-pad"
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.billingDay?.message}
                  helper="If the month has fewer days, the bill is charged on its last day."
                  className=""
                />
              )}
            />
          </View>

          <Button
            title={isEditing ? "Save changes" : "Add subscription"}
            fullWidth
            loading={isPending || isSubmitting}
            disabled={isPending || isSubmitting || isOffline}
            onPress={handleSubmit(onSubmit)}
            className="mb-8 mt-6"
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
