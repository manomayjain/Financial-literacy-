import { Text, View } from "react-native";

export interface DueBadgeProps {
  daysUntilNextBilling: number | null;
  active: boolean;
}

export function DueBadge({ daysUntilNextBilling, active }: DueBadgeProps) {
  if (!active) {
    return (
      <View className="flex-row items-center rounded-full border border-border bg-surface px-2.5 py-1">
        <Text className="text-xs font-medium text-muted">Inactive</Text>
      </View>
    );
  }

  if (daysUntilNextBilling === null) return null;

  const label =
    daysUntilNextBilling === 0
      ? "Due today"
      : daysUntilNextBilling === 1
        ? "Due tomorrow"
        : `Due in ${daysUntilNextBilling} days`;

  const isUrgent = daysUntilNextBilling <= 3;
  const isSoon = daysUntilNextBilling <= 7;

  const styles = isUrgent
    ? "bg-danger"
    : isSoon
      ? "bg-warning"
      : "border border-border bg-surface";

  const textColor = isUrgent || isSoon ? "text-white" : "text-muted";

  return (
    <View className={["flex-row items-center rounded-full px-2.5 py-1", styles].join(" ")}>
      <Text className={`text-xs font-semibold ${textColor}`}>{label}</Text>
    </View>
  );
}