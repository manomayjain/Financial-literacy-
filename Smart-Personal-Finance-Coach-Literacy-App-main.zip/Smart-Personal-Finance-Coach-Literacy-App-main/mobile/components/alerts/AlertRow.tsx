import { Ionicons } from "@expo/vector-icons";
import { Pressable, Text, View } from "react-native";
import type { AppAlert } from "@/hooks/useAlerts";
import { formatRelativeTime } from "@/lib/format";

export interface AlertRowProps {
  alert: AppAlert;
  onPress: () => void;
  pending?: boolean;
}

export function AlertRow({ alert, onPress, pending }: AlertRowProps) {
  const isOverspend = alert.type === "OVERSPEND";

  return (
    <Pressable
      onPress={onPress}
      disabled={pending}
      accessibilityRole="button"
      className={[
        "mb-2 flex-row items-center rounded-xl border border-border bg-surface p-3",
        alert.isRead ? "opacity-70" : "",
      ].join(" ")}
    >
      <View
        className={[
          "mr-3 h-10 w-10 items-center justify-center rounded-full",
          isOverspend ? "bg-danger/15" : "bg-warning/15",
        ].join(" ")}
      >
        <Ionicons
          name={isOverspend ? "alert-circle" : "notifications"}
          size={20}
          color={isOverspend ? "#EF4444" : "#D97706"}
        />
      </View>

      <View className="flex-1">
        <Text
          className={[
            "text-sm",
            alert.isRead ? "text-muted" : "font-medium text-white",
          ].join(" ")}
        >
          {alert.message}
        </Text>
        <View className="mt-1 flex-row items-center">
          <Text className="text-xs text-muted">
            {formatRelativeTime(alert.createdAt)}
          </Text>
          {alert.article ? (
            <View className="ml-2 flex-row items-center">
              <Ionicons name="book-outline" size={12} color="#94A3B8" />
              <Text className="ml-1 text-xs text-primary">
                {alert.article.title}
              </Text>
            </View>
          ) : null}
        </View>
      </View>

      {!alert.isRead ? (
        <View className="ml-2 h-2 w-2 rounded-full bg-primary" />
      ) : null}
      {alert.article ? (
        <Ionicons name="chevron-forward" size={16} color="#94A3B8" />
      ) : null}
    </Pressable>
  );
}