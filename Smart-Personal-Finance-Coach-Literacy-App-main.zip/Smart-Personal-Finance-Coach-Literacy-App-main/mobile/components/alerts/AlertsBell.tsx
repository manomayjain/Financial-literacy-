import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { useAlerts } from "@/hooks/useAlerts";

export function AlertsBell() {
  const alerts = useAlerts();
  const unreadCount = alerts.data?.unreadCount ?? 0;

  return (
    <Pressable
      onPress={() => router.push("/alerts")}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={`Alerts, ${unreadCount} unread`}
      className="relative mr-2 p-1"
    >
      <Ionicons name="notifications-outline" size={22} color="#FFFFFF" />
      {unreadCount > 0 ? (
        <View className="absolute -right-0.5 -top-0.5 min-w-4 items-center justify-center rounded-full bg-danger px-1">
          <Text className="text-[10px] font-bold leading-4 text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </Text>
        </View>
      ) : null}
    </Pressable>
  );
}