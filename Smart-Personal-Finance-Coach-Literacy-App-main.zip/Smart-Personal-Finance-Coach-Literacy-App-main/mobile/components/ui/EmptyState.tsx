import { useEffect, useRef } from "react";
import { Animated, StyleProp, Text, View, ViewStyle } from "react-native";

export interface EmptyStateProps {
  title: string;
  message?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

export function EmptyState({
  title,
  message,
  icon,
  action,
  style,
}: EmptyStateProps) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(8)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, {
        toValue: 1,
        duration: 280,
        useNativeDriver: true,
      }),
      Animated.timing(translateY, {
        toValue: 0,
        duration: 280,
        useNativeDriver: true,
      }),
    ]).start();
  }, [opacity, translateY]);

  return (
    <Animated.View
      className="items-center justify-center px-8 py-12"
      style={[style, { opacity, transform: [{ translateY }] }]}
    >
      {icon ? <View className="mb-4">{icon}</View> : null}
      <Text className="text-center text-lg font-semibold text-white">
        {title}
      </Text>
      {message ? (
        <Text className="mt-2 text-center text-sm text-muted">{message}</Text>
      ) : null}
      {action ? <View className="mt-6">{action}</View> : null}
    </Animated.View>
  );
}
