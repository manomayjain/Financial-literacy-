import { Ionicons } from "@expo/vector-icons";
import { Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNetworkStore } from "@/store/networkStore";

export function NetworkBanner() {
  const insets = useSafeAreaInsets();
  const isOnline = useNetworkStore((state) => state.isOnline);

  if (isOnline) return null;

  return (
    <View
      className="flex-row items-center justify-center bg-warning-dark px-4 pb-2.5"
      style={{ paddingTop: insets.top }}
    >
      <Ionicons name="cloud-offline-outline" size={16} color="#FFFFFF" />
      <Text className="ml-2 text-sm font-semibold text-white">
        You’re offline — changes can’t be saved.
      </Text>
    </View>
  );
}