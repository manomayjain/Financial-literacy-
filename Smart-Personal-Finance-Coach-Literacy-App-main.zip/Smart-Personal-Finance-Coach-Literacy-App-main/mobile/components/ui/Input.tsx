import { forwardRef, useState } from "react";
import {
  Text,
  TextInput,
  TextInputProps,
  View,
} from "react-native";

export interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  helper?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  className?: string;
}

export const Input = forwardRef<TextInput, InputProps>(function Input(
  { label, error, helper, leftIcon, rightIcon, editable = true, onFocus, onBlur, className, ...rest },
  ref,
) {
  const [isFocused, setIsFocused] = useState(false);
  const hasError = Boolean(error);

  return (
    <View className={["w-full mb-4", className].join(" ")}>
      {label ? (
        <Text className="mb-2 text-sm font-semibold text-white">
          {label}
        </Text>
      ) : null}

      <View
        className={[
          "flex-row items-center rounded-xl border bg-surface",
          hasError
            ? "border-danger"
            : isFocused
              ? "border-primary"
              : "border-border",
          !editable ? "opacity-60" : "",
        ].join(" ")}
        style={{ height: 48 }}
      >
        {leftIcon ? <View className="pl-3 justify-center">{leftIcon}</View> : null}
        <TextInput
          ref={ref}
          editable={editable}
          placeholderTextColor="#94A3B8"
          className="flex-1 px-4 text-base text-white font-medium"
          style={{ height: "100%", paddingVertical: 0 }}
          onFocus={(e) => {
            setIsFocused(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setIsFocused(false);
            onBlur?.(e);
          }}
          {...rest}
        />
        {rightIcon ? <View className="pr-3 justify-center">{rightIcon}</View> : null}
      </View>

      {hasError ? (
        <Text className="mt-1.5 text-xs font-medium text-danger">{error}</Text>
      ) : helper ? (
        <Text className="mt-1.5 text-xs text-muted">{helper}</Text>
      ) : null}
    </View>
  );
});