import { Modal, Text, View } from "react-native";
import { Button } from "./Button";

export interface ConfirmModalProps {
  visible: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
}

export function ConfirmModal({
  visible,
  title,
  message,
  confirmLabel = "Confirm",
  onCancel,
  onConfirm,
}: ConfirmModalProps) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View className="flex-1 items-center justify-center bg-black/60 px-6">
        <View className="w-full max-w-md rounded-2xl border border-border bg-surface p-5">
          <Text className="text-lg font-semibold text-white">{title}</Text>
          <Text className="mt-2 text-sm leading-5 text-muted">{message}</Text>
          <View className="mt-6 flex-row justify-end gap-3">
            <Button title="Cancel" variant="secondary" size="sm" onPress={onCancel} />
            <Button title={confirmLabel} size="sm" onPress={onConfirm} />
          </View>
        </View>
      </View>
    </Modal>
  );
}
