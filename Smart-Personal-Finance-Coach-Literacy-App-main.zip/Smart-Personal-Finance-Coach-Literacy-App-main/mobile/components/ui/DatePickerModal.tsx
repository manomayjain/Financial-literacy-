import { useEffect, useMemo, useState } from "react";
import { Ionicons } from "@expo/vector-icons";
import { Modal, Pressable, Text, View } from "react-native";
import { Button } from "./Button";

export interface DatePickerModalProps {
  visible: boolean;
  selectedDate: Date;
  minimumDate?: Date;
  maximumDate?: Date;
  onCancel: () => void;
  onConfirm: (date: Date) => void;
}

const WEEK_DAYS = ["S", "M", "T", "W", "T", "F", "S"];

function startOfDay(date: Date): Date {
  const result = new Date(date);
  result.setHours(0, 0, 0, 0);
  return result;
}

function monthStart(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function addMonths(date: Date, amount: number): Date {
  return new Date(date.getFullYear(), date.getMonth() + amount, 1);
}

function isSameDay(left: Date, right: Date): boolean {
  return left.toDateString() === right.toDateString();
}

export function DatePickerModal({
  visible,
  selectedDate,
  minimumDate,
  maximumDate,
  onCancel,
  onConfirm,
}: DatePickerModalProps) {
  const [draftDate, setDraftDate] = useState(() => startOfDay(selectedDate));
  const [month, setMonth] = useState(() => monthStart(selectedDate));

  useEffect(() => {
    if (visible) {
      setDraftDate(startOfDay(selectedDate));
      setMonth(monthStart(selectedDate));
    }
  }, [selectedDate, visible]);

  const days = useMemo(() => {
    const firstDay = month.getDay();
    const count = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
    return Array.from({ length: firstDay + count }, (_, index) =>
      index < firstDay ? null : new Date(month.getFullYear(), month.getMonth(), index - firstDay + 1),
    );
  }, [month]);

  const minimum = minimumDate ? startOfDay(minimumDate) : null;
  const maximum = maximumDate ? startOfDay(maximumDate) : null;

  const isDisabled = (date: Date) =>
    (minimum !== null && date < minimum) || (maximum !== null && date > maximum);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View className="flex-1 items-center justify-center bg-black/60 px-5">
        <View className="w-full max-w-md rounded-2xl border border-border bg-surface p-5">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-xs font-medium uppercase tracking-wide text-muted">
                Select date
              </Text>
              <Text className="mt-1 text-lg font-semibold text-white">
                {draftDate.toLocaleDateString(undefined, {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </Text>
            </View>
            <Pressable
              onPress={onCancel}
              hitSlop={10}
              className="h-10 w-10 items-center justify-center rounded-full bg-background"
              accessibilityRole="button"
              accessibilityLabel="Close date picker"
            >
              <Ionicons name="close" size={20} color="#94A3B8" />
            </Pressable>
          </View>

          <View className="mt-5 flex-row items-center justify-between">
            <Pressable
              onPress={() => setMonth((value) => addMonths(value, -1))}
              className="h-10 w-10 items-center justify-center rounded-lg bg-background"
              accessibilityRole="button"
              accessibilityLabel="Previous month"
            >
              <Ionicons name="chevron-back" size={18} color="#FFFFFF" />
            </Pressable>
            <Text className="text-base font-semibold text-white">
              {month.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
            </Text>
            <Pressable
              onPress={() => setMonth((value) => addMonths(value, 1))}
              className="h-10 w-10 items-center justify-center rounded-lg bg-background"
              accessibilityRole="button"
              accessibilityLabel="Next month"
            >
              <Ionicons name="chevron-forward" size={18} color="#FFFFFF" />
            </Pressable>
          </View>

          <View className="mt-4 flex-row justify-between">
            {WEEK_DAYS.map((day, index) => (
              <Text key={`${day}-${index}`} className="w-9 text-center text-xs font-semibold text-muted">
                {day}
              </Text>
            ))}
          </View>

          <View className="mt-2 flex-row flex-wrap">
            {days.map((date, index) => {
              if (!date) {
                return <View key={`empty-${index}`} className="m-0.5 h-10 w-9" />;
              }
              const disabled = isDisabled(date);
              const selected = isSameDay(date, draftDate);
              return (
                <Pressable
                  key={date.toISOString()}
                  disabled={disabled}
                  onPress={() => setDraftDate(date)}
                  className={[
                    "m-0.5 h-10 w-9 items-center justify-center rounded-lg",
                    selected ? "bg-primary" : "bg-transparent",
                    disabled ? "opacity-30" : "",
                  ].join(" ")}
                >
                  <Text className={selected ? "text-sm font-semibold text-white" : "text-sm text-white"}>
                    {date.getDate()}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <View className="mt-5 flex-row justify-end gap-3">
            <Button title="Cancel" variant="secondary" size="sm" onPress={onCancel} />
            <Button title="Use date" size="sm" onPress={() => onConfirm(draftDate)} />
          </View>
        </View>
      </View>
    </Modal>
  );
}
