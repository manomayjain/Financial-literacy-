import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { api, extractData, isOfflineError, type ApiBody } from "@/lib/api";
import { toast } from "@/store/toastStore";

export interface QuizAttemptResult {
  id: string;
  score: number;
  total: number;
  passed: boolean;
  createdAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  earned: boolean;
  current: number;
  needed: number;
  progress: number;
}

export function useSubmitQuizAttempt(quizId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (answers: number[]) =>
      api
        .post<ApiBody<{ attempt: QuizAttemptResult }>>(
          `/quizzes/${quizId}/attempt`,
          { answers },
        )
        .then(extractData)
        .then((data) => data.attempt),
    onSuccess: () => {
      toast("Quiz completed", "success");
      void queryClient.invalidateQueries({ queryKey: ["badges"] });
    },
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't submit your quiz. Please try again.", "error");
    },
  });
}

export function useBadges() {
  return useQuery<Badge[]>({
    queryKey: ["badges"],
    queryFn: () =>
      api
        .get<ApiBody<{ badges: Badge[] }>>("/users/me/badges")
        .then(extractData)
        .then((data) => data.badges),
  });
}