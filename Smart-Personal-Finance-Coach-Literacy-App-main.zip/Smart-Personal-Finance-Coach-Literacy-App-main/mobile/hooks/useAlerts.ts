import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import {
  api,
  extractData,
  isOfflineError,
  type ApiBody,
} from "@/lib/api";
import { toast } from "@/store/toastStore";

export type AlertType = "OVERSPEND" | "SUBSCRIPTION_DUE";

export interface AlertArticle {
  id: string;
  title: string;
}

export interface AppAlert {
  id: string;
  type: AlertType;
  message: string;
  isRead: boolean;
  articleId: string | null;
  createdAt: string;
  article: AlertArticle | null;
}

export interface AlertsData {
  alerts: AppAlert[];
  unreadCount: number;
}

const ALERTS_KEY = ["alerts"] as const;

export function useAlerts() {
  return useQuery<AlertsData>({
    queryKey: ALERTS_KEY,
    queryFn: () => api.get<ApiBody<AlertsData>>("/alerts").then(extractData),
    refetchInterval: 60 * 1000,
    refetchOnWindowFocus: true,
  });
}

export function useMarkAlertRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) =>
      api
        .patch<ApiBody<{ alert: AppAlert }>>(`/alerts/${id}/read`)
        .then(extractData),
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't update alert. Please try again.", "error");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ALERTS_KEY });
    },
  });
}

export function useMarkAllAlertsRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () =>
      api
        .patch<ApiBody<{ count: number }>>("/alerts/read-all")
        .then(extractData),
    onSuccess: () => {
      toast("All alerts marked as read", "success");
    },
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't update alerts. Please try again.", "error");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ALERTS_KEY });
    },
  });
}