import { NetInfoState, NetInfoStateType } from "@react-native-community/netinfo";
import { useNetworkStore } from "@/store/networkStore";

export interface NetworkStatus {
  isOnline: boolean;
  isInternetReachable: boolean | null;
  type: NetInfoStateType;
  details: NetInfoState["details"];
}

export function useNetworkStatus(): NetworkStatus {
  return useNetworkStore();
}