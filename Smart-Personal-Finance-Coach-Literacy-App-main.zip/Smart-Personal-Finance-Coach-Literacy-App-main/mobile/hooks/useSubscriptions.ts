import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import {
  api,
  extractData,
  isOfflineError,
  type ApiBody,
} from "@/lib/api";
import { toast } from "@/store/toastStore";

export interface Subscription {
  id: string;
  name: string;
  amount: number;
  billingDay: number;
  active: boolean;
  nextBillingDate: string | null;
  daysUntilNextBilling: number | null;
}

export interface CreateSubscriptionInput {
  name: string;
  amount: number;
  billingDay: number;
}

export interface UpdateSubscriptionInput {
  name?: string;
  amount?: number;
  billingDay?: number;
  active?: boolean;
}

interface SubscriptionResult {
  subscription: Subscription;
  warnings: string[];
}

const SUBSCRIPTIONS_KEY = ["subscriptions"] as const;

function showWarnings(warnings?: string[]) {
  if (!warnings || warnings.length === 0) return;
  for (const warning of warnings) {
    toast(warning, "info");
  }
}

export function useSubscriptions() {
  return useQuery<Subscription[]>({
    queryKey: SUBSCRIPTIONS_KEY,
    queryFn: () =>
      api
        .get<ApiBody<{ subscriptions: Subscription[] }>>("/subscriptions")
        .then(extractData)
        .then((data) => data.subscriptions),
  });
}

export function useCreateSubscription() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (input: CreateSubscriptionInput) =>
      api
        .post<ApiBody<SubscriptionResult>>("/subscriptions", input)
        .then(extractData),
    onSuccess: (data) => {
      toast(`"${data.subscription.name}" added`, "success");
      showWarnings(data.warnings);
    },
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't add subscription. Please try again.", "error");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: SUBSCRIPTIONS_KEY });
    },
  });
}

export function useUpdateSubscription() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: UpdateSubscriptionInput }) =>
      api
        .patch<ApiBody<SubscriptionResult>>(`/subscriptions/${id}`, input)
        .then(extractData),
    onSuccess: (data) => {
      toast(`"${data.subscription.name}" updated`, "success");
      showWarnings(data.warnings);
    },
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't update subscription. Please try again.", "error");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: SUBSCRIPTIONS_KEY });
    },
  });
}

export function useDeleteSubscription() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) =>
      api
        .delete<ApiBody<{ id: string }>>(`/subscriptions/${id}`)
        .then(extractData),
    onSuccess: () => {
      toast("Subscription removed", "success");
    },
    onError: (error) => {
      if (isOfflineError(error)) return;
      toast("Couldn't delete subscription. Please try again.", "error");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: SUBSCRIPTIONS_KEY });
    },
  });
}