import { useQuery } from "@tanstack/react-query";
import { api, extractData, type ApiBody } from "@/lib/api";

export interface ArticleSummary {
  id: string;
  title: string;
  summary: string;
  tag: string;
}

export interface ArticleQuestion {
  id: string;
  text: string;
  options: string[];
  correctIndex: number;
}

export interface ArticleQuiz {
  id: string;
  questions: ArticleQuestion[];
}

export interface ArticleDetail extends ArticleSummary {
  body: string;
  quiz: ArticleQuiz | null;
}

export function useArticles() {
  return useQuery<ArticleSummary[]>({
    queryKey: ["articles"],
    queryFn: () =>
      api
        .get<ApiBody<{ articles: ArticleSummary[] }>>("/articles")
        .then(extractData)
        .then((data) => data.articles),
  });
}

export function useArticle(id?: string) {
  return useQuery<ArticleDetail>({
    queryKey: ["articles", id],
    enabled: Boolean(id),
    queryFn: () =>
      api
        .get<ApiBody<{ article: ArticleDetail }>>(`/articles/${id}`)
        .then(extractData)
        .then((data) => data.article),
  });
}