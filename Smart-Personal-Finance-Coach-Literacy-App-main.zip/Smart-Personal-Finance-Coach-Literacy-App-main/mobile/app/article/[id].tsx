import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { Button, EmptyState, ErrorState, Skeleton } from "@/components/ui";
import { QuizView } from "@/components/learn/QuizView";
import { useArticle } from "@/hooks/useArticles";
import { getErrorCode } from "@/lib/api";
import { formatTag } from "@/lib/articleTags";

export default function ArticleDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const article = useArticle(id);

  if (!id) {
    return (
      <View className="flex-1 bg-background p-4">
        <EmptyState
          title="Article not found"
          message="This article may have been removed or the link is invalid."
          icon={<Ionicons name="book-outline" size={48} color="#94A3B8" />}
          action={
            <Button title="Back to learn" variant="outline" onPress={() => router.back()} />
          }
        />
      </View>
    );
  }

  if (article.isLoading) {
    return (
      <View className="flex-1 bg-background p-4">
        <Skeleton height={28} className="mb-2" />
        <Skeleton height={14} width="70%" className="mb-6" />
        <Skeleton height={80} className="mb-3" />
        <Skeleton height={80} className="mb-3" />
        <Skeleton height={80} />
      </View>
    );
  }

  if (article.isError || !article.data) {
    if (getErrorCode(article.error) === "ARTICLE_NOT_FOUND") {
      return (
        <View className="flex-1 bg-background p-4">
          <EmptyState
            title="Article not found"
            message="This article may have been removed or the link is invalid."
            icon={<Ionicons name="book-outline" size={48} color="#94A3B8" />}
            action={
              <Button title="Back to learn" variant="outline" onPress={() => router.back()} />
            }
          />
        </View>
      );
    }

    return (
      <View className="flex-1 bg-background">
        <ErrorState onRetry={() => void article.refetch()} />
      </View>
    );
  }

  const data = article.data;
  const paragraphs = data.body.split(/\n\n+/);

  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerStyle={{ padding: 16, paddingBottom: 112 }}
      showsVerticalScrollIndicator={false}
    >
      <View className="self-start rounded-full bg-primary/15 px-2.5 py-1">
        <Text className="text-xs font-semibold text-primary">
          {formatTag(data.tag)}
        </Text>
      </View>

      <Text className="mt-3 text-2xl font-bold leading-8 text-white">{data.title}</Text>
      <Text className="mt-2 text-sm leading-5 text-muted">{data.summary}</Text>

      <View className="mt-5 rounded-2xl border border-border bg-surface p-4">
        {paragraphs.map((paragraph, index) => (
          <Text
            key={`${data.id}-${index}`}
            className="mb-4 text-[15px] leading-6 text-slate-200 last:mb-0"
          >
            {paragraph}
          </Text>
        ))}
      </View>

      {data.quiz ? (
        <View className="mt-6 rounded-2xl border border-border bg-surface p-4">
          <Text className="text-lg font-bold text-white">Quick quiz</Text>
          <Text className="mt-1 text-sm text-muted">
            Answer all 3 questions to earn a badge on your profile.
          </Text>
          <QuizView quiz={data.quiz} />
        </View>
      ) : null}
    </ScrollView>
  );
}
