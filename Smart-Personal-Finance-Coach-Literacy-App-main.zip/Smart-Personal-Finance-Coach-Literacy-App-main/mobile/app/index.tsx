import { Redirect } from "expo-router";
import { ActivityIndicator, Image, Text, View } from "react-native";
import { useAuthStore } from "@/store/authStore";

export default function IndexScreen() {
  const isLoading = useAuthStore((state) => state.isLoading);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  if (isLoading) {
    return (
      <View className="flex-1 items-center justify-center bg-background px-8">
        <Image
          source={require("@/assets/images/icon.png")}
          className="h-20 w-20 rounded-3xl"
          accessibilityLabel="Smart Finance Coach logo"
        />
        <Text className="mt-4 text-lg font-bold text-white">Smart Finance Coach</Text>
        <Text className="mt-1 text-sm text-muted">Building your money snapshot...</Text>
        <ActivityIndicator size="large" color="#208AEF" style={{ marginTop: 24 }} />
      </View>
    );
  }

  return <Redirect href={isAuthenticated ? "/dashboard" : "/login"} />;
}
