import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useMemo } from "react";
import { FlatList, RefreshControl, Text, View } from "react-native";
import { Button, EmptyState, ErrorState, Skeleton } from "@/components/ui";
import { AlertRow } from "@/components/alerts/AlertRow";
import {
  useAlerts,
  useMarkAllAlertsRead,
  useMarkAlertRead,
  type AppAlert,
} from "@/hooks/useAlerts";

type AlertSkeleton = { kind: "skeleton"; key: string };
type AlertRowType = AppAlert | AlertSkeleton;

export default function AlertsScreen() {
  const alerts = useAlerts();
  const markRead = useMarkAlertRead();
  const markAll = useMarkAllAlertsRead();

  const rows = useMemo<AlertRowType[]>(() => {
    if (alerts.isLoading) {
      return Array.from({ length: 3 }).map((_, index) => ({
        kind: "skeleton" as const,
        key: `s-${index}`,
      }));
    }
    return alerts.data?.alerts ?? [];
  }, [alerts.isLoading, alerts.data]);

  const unreadCount = alerts.data?.unreadCount ?? 0;
  const hasAlerts = (alerts.data?.alerts.length ?? 0) > 0;

  const openAlert = (alert: AppAlert) => {
    if (!alert.isRead) {
      markRead.mutate(alert.id);
    }
    if (alert.articleId) {
      router.push(`/article/${alert.articleId}`);
    }
  };

  const refresh = () => void alerts.refetch();

  return (
    <View className="flex-1 bg-background">
      <View className="mx-4 mb-1 mt-4 flex-row items-center rounded-2xl border border-border bg-surface p-4">
        <View className="mr-3 h-11 w-11 items-center justify-center rounded-2xl bg-primary/15">
          <Ionicons name="notifications-outline" size={22} color="#208AEF" />
        </View>
        <View className="flex-1">
          <Text className="text-xl font-bold text-white">Notifications</Text>
          <Text className="mt-0.5 text-sm text-muted">
            Stay on top of your spending habits.
          </Text>
        </View>
        {unreadCount > 0 ? (
          <View className="min-w-7 items-center rounded-full bg-primary px-2 py-1">
            <Text className="text-xs font-bold text-white">{unreadCount}</Text>
          </View>
        ) : null}
      </View>
      {hasAlerts ? (
        <View className="flex-row items-center justify-between px-4 py-3">
          <Text className="text-sm text-muted">
            {unreadCount === 0
              ? "All caught up"
              : `${unreadCount} unread alert${unreadCount === 1 ? "" : "s"}`}
          </Text>
          {unreadCount > 0 ? (
            <Button
              title="Mark all as read"
              size="sm"
              variant="ghost"
              loading={markAll.isPending}
              onPress={() => markAll.mutate()}
            />
          ) : null}
        </View>
      ) : null}

      <FlatList
        className="flex-1 px-3"
        data={rows}
        keyExtractor={(item) => ("kind" in item ? item.key : item.id)}
        renderItem={({ item }) =>
          "kind" in item ? (
            <Skeleton height={72} className="mb-2" />
          ) : (
            <AlertRow
              alert={item}
              onPress={() => openAlert(item)}
              pending={markRead.isPending}
            />
          )
        }
        contentContainerStyle={{
          paddingTop: 4,
          paddingBottom: 112,
          flexGrow: 1,
        }}
        refreshControl={
          <RefreshControl
            refreshing={alerts.isRefetching}
            onRefresh={refresh}
            tintColor="#208AEF"
            colors={["#208AEF"]}
          />
        }
        ListEmptyComponent={
          alerts.isLoading ? null : alerts.isError ? (
            <ErrorState onRetry={refresh} />
          ) : (
            <EmptyState
              title="You're all caught up!"
              message="Spending and subscription reminders will show up here."
              icon={
                <Ionicons
                  name="notifications-off-outline"
                  size={48}
                  color="#94A3B8"
                />
              }
            />
          )
        }
      />
    </View>
  );
}
