import { router } from "expo-router";
import { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Button, Card, ConfirmModal } from "@/components/ui";
import { BadgesSection } from "@/components/profile/BadgesSection";
import { useAuth } from "@/hooks/useAuth";
import { useAuthStore } from "@/store/authStore";

export default function ProfileScreen() {
  const { user } = useAuth();
  const logout = useAuthStore((state) => state.logout);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [signOutVisible, setSignOutVisible] = useState(false);

  const handleLogout = async () => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    try {
      await logout();
      router.replace("/login");
    } finally {
      setIsLoggingOut(false);
    }
  };

  const confirmLogout = () => {
    if (isLoggingOut) return;
    setSignOutVisible(true);
  };

  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerStyle={{ padding: 16, paddingBottom: 112 }}
    >
      <Card className="mb-6">
        <View className="flex-row items-center">
          <View className="mr-4 h-14 w-14 items-center justify-center rounded-full bg-primary">
            <Text className="text-xl font-bold text-white">
              {(user?.name ?? "S").slice(0, 1).toUpperCase()}
            </Text>
          </View>
          <View className="flex-1">
            <Text className="text-xs font-medium uppercase tracking-wide text-muted">Account</Text>
            <Text className="mt-1 text-xl font-bold text-white">
              {user?.name ?? "Signed in"}
            </Text>
            <Text className="mt-1 text-sm text-muted">
              {user?.email ?? "Manage your account here."}
            </Text>
          </View>
        </View>
      </Card>

      <BadgesSection />

      <Button
        title="Sign out"
        leftIcon={<Ionicons name="log-out-outline" size={18} color="#FFFFFF" />}
        fullWidth
        loading={isLoggingOut}
        disabled={isLoggingOut}
        onPress={confirmLogout}
      />

      <ConfirmModal
        visible={signOutVisible}
        title="Sign out?"
        message="You can sign back in anytime."
        confirmLabel="Sign out"
        onCancel={() => setSignOutVisible(false)}
        onConfirm={() => {
          setSignOutVisible(false);
          void handleLogout();
        }}
      />
    </ScrollView>
  );
}
