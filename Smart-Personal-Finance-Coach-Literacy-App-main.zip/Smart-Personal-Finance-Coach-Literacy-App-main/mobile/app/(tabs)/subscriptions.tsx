import { Ionicons } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { FlatList, RefreshControl, Text, View } from "react-native";
import { Button, ConfirmModal, EmptyState, ErrorState, Skeleton } from "@/components/ui";
import { SubscriptionRow } from "@/components/subscription/SubscriptionRow";
import { SubscriptionForm } from "@/components/subscription/SubscriptionForm";
import {
  useDeleteSubscription,
  useSubscriptions,
  useUpdateSubscription,
  type Subscription,
} from "@/hooks/useSubscriptions";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";
import { formatCurrency } from "@/lib/format";

type SubscriptionSkeleton = { kind: "skeleton"; key: string };
type SubscriptionRowType = Subscription | SubscriptionSkeleton;

export default function SubscriptionsScreen() {
  const { isOnline } = useNetworkStatus();
  const subscriptions = useSubscriptions();
  const updateSubscription = useUpdateSubscription();
  const deleteSubscription = useDeleteSubscription();

  const [formVisible, setFormVisible] = useState(false);
  const [editing, setEditing] = useState<Subscription | null>(null);
  const [deleting, setDeleting] = useState<Subscription | null>(null);

  const rows = useMemo<SubscriptionRowType[]>(() => {
    if (subscriptions.isLoading) {
      return Array.from({ length: 3 }).map((_, index) => ({
        kind: "skeleton" as const,
        key: `s-${index}`,
      }));
    }
    const sorted = [...(subscriptions.data ?? [])].sort((a, b) => {
      if (a.active !== b.active) return a.active ? -1 : 1;
      return (a.daysUntilNextBilling ?? Number.POSITIVE_INFINITY) -
        (b.daysUntilNextBilling ?? Number.POSITIVE_INFINITY);
    });
    return sorted;
  }, [subscriptions.isLoading, subscriptions.data]);

  const activeSubs = useMemo(
    () => (subscriptions.data ?? []).filter((sub) => sub.active),
    [subscriptions.data],
  );
  const totalMonthly = activeSubs.reduce((sum, sub) => sum + sub.amount, 0);

  const openCreate = () => {
    setEditing(null);
    setFormVisible(true);
  };

  const openEdit = (subscription: Subscription) => {
    setEditing(subscription);
    setFormVisible(true);
  };

  const closeForm = () => {
    setFormVisible(false);
    setEditing(null);
  };

  const toggleActive = (subscription: Subscription, active: boolean) => {
    updateSubscription.mutate({ id: subscription.id, input: { active } });
  };

  const confirmDelete = (subscription: Subscription) => {
    setDeleting(subscription);
  };

  const refresh = () => void subscriptions.refetch();

  return (
    <View className="flex-1 bg-background">
      {activeSubs.length > 0 ? (
        <View className="flex-row items-center justify-between px-4 pt-4">
          <Text className="text-sm text-muted">
            {activeSubs.length} active · {subscriptions.data!.length} total
          </Text>
          <Text className="text-base font-semibold text-white">
            {formatCurrency(totalMonthly)}/mo
          </Text>
        </View>
      ) : null}

      <FlatList
        className="flex-1 px-3"
        data={rows}
        keyExtractor={(item) => ("kind" in item ? item.key : item.id)}
        renderItem={({ item }) =>
          "kind" in item ? (
            <Skeleton height={96} className="mb-3" />
          ) : (
            <SubscriptionRow
              subscription={item}
              onEdit={() => openEdit(item)}
              onDelete={() => confirmDelete(item)}
              onToggle={(active) => toggleActive(item, active)}
              pending={updateSubscription.isPending}
            />
          )
        }
        contentContainerStyle={{ paddingBottom: 120, flexGrow: 1 }}
        refreshControl={
          <RefreshControl
            refreshing={subscriptions.isRefetching}
            onRefresh={refresh}
            tintColor="#208AEF"
            colors={["#208AEF"]}
          />
        }
        ListEmptyComponent={
          subscriptions.isLoading ? null : subscriptions.isError ? (
            <ErrorState onRetry={refresh} />
          ) : (
            <EmptyState
              title="No subscriptions yet"
              message="Track recurring bills like streaming, subscriptions and memberships."
              icon={<Ionicons name="card-outline" size={48} color="#94A3B8" />}
              action={<Button title="Add your first subscription" onPress={openCreate} />}
            />
          )
        }
      />

      <Button
        title=""
        leftIcon={<Ionicons name="add" size={24} color="#FFFFFF" />}
        style={{
          position: "absolute",
          right: 20,
          bottom: 104,
          width: 56,
          height: 56,
          borderRadius: 28,
          zIndex: 10,
        }}
        accessibilityLabel="Add subscription"
        onPress={openCreate}
      />

      <ConfirmModal
        visible={deleting !== null}
        title="Delete subscription?"
        message={
          deleting
            ? `${deleting.name} (${formatCurrency(deleting.amount)}/mo, billing day ${deleting.billingDay}) will be permanently removed.`
            : ""
        }
        confirmLabel="Delete"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) deleteSubscription.mutate(deleting.id);
          setDeleting(null);
        }}
      />

      <SubscriptionForm
        visible={formVisible}
        initialValues={editing}
        isOffline={!isOnline}
        onClose={closeForm}
      />
    </View>
  );
}
