import { Ionicons } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { FlatList, RefreshControl, ScrollView, View } from "react-native";
import { Chip, EmptyState, ErrorState, Skeleton } from "@/components/ui";
import { ArticleCard } from "@/components/learn/ArticleCard";
import type { ArticleSummary } from "@/hooks/useArticles";
import { useArticles } from "@/hooks/useArticles";
import { formatTag } from "@/lib/articleTags";

type ArticleSkeleton = { kind: "skeleton"; key: string };
type ArticleRow = ArticleSummary | ArticleSkeleton;

export default function LearnScreen() {
  const articles = useArticles();
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const tags = useMemo(() => {
    const seen = new Set<string>();
    for (const article of articles.data ?? []) {
      seen.add(article.tag);
    }
    return [...seen].sort();
  }, [articles.data]);

  const filtered = useMemo(
    () =>
      selectedTag
        ? (articles.data ?? []).filter((article) => article.tag === selectedTag)
        : articles.data ?? [],
    [articles.data, selectedTag],
  );

  const rows = useMemo<ArticleRow[]>(() => {
    if (articles.isLoading) {
      return Array.from({ length: 4 }).map((_, index) => ({
        kind: "skeleton" as const,
        key: `s-${index}`,
      }));
    }
    return filtered;
  }, [articles.isLoading, filtered]);

  const refresh = () => void articles.refetch();

  return (
    <View className="flex-1 bg-background">
      <FlatList
        className="flex-1"
        data={rows}
        keyExtractor={(item) => ("kind" in item ? item.key : item.id)}
        renderItem={({ item }) =>
          "kind" in item ? (
            <View className="px-4">
              <Skeleton height={120} className="mb-3" />
            </View>
          ) : (
            <View className="px-4">
              <ArticleCard article={item} />
            </View>
          )
        }
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 112, flexGrow: 1 }}
        ListHeaderComponent={
          tags.length > 0 ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              className="mb-4 flex-grow-0"
              contentContainerStyle={{ paddingHorizontal: 16 }}
            >
              <Chip
                label="All"
                selected={selectedTag === null}
                onPress={() => setSelectedTag(null)}
              />
              {tags.map((tag) => (
                <Chip
                  key={tag}
                  label={formatTag(tag)}
                  selected={selectedTag === tag}
                  onPress={() => setSelectedTag(tag)}
                />
              ))}
            </ScrollView>
          ) : null
        }
        refreshControl={
          <RefreshControl
            refreshing={articles.isRefetching}
            onRefresh={refresh}
            tintColor="#208AEF"
            colors={["#208AEF"]}
          />
        }
        ListEmptyComponent={
          articles.isLoading ? null : articles.isError ? (
            <ErrorState onRetry={refresh} />
          ) : (
            <EmptyState
              title="No articles here"
              message={
                selectedTag
                  ? `No ${formatTag(selectedTag)} articles yet. Try another topic.`
                  : "Learning articles are on their way."
              }
              icon={<Ionicons name="book-outline" size={48} color="#94A3B8" />}
            />
          )
        }
      />
    </View>
  );
}
