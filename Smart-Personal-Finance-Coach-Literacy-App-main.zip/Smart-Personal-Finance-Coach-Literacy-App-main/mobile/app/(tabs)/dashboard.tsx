import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { RefreshControl, ScrollView, Text, View } from "react-native";
import {
  Button,
  Card,
  EmptyState,
  ErrorState,
  Skeleton,
} from "@/components/ui";
import { SpendByCategory } from "@/components/ledger/SpendByCategory";
import { useLedgerSummary } from "@/hooks/useLedger";
import { formatCurrency, formatSignedCurrency } from "@/lib/format";

interface SummaryRowProps {
  label: string;
  income: number;
  expense: number;
  highlight?: boolean;
}

function SummaryRow({
  label,
  income,
  expense,
  highlight = false,
}: SummaryRowProps) {
  const net = income - expense;

  return (
    <View
      className={[
        "flex-row items-center px-2 py-3",
        highlight ? "rounded-lg bg-primary/10" : "",
      ].join(" ")}
    >
      <Text
        className="text-sm font-semibold text-white"
        style={{ width: "24%", flexGrow: 0, flexShrink: 0 }}
        numberOfLines={1}
      >
        {label}
      </Text>
      <Text className="w-[21%] text-right text-sm text-slate-200">
        {formatCurrency(income)}
      </Text>
      <Text className="w-[21%] text-right text-sm text-slate-200">
        {formatCurrency(expense)}
      </Text>
      <Text
        className="w-[34%] text-right text-sm font-semibold"
        style={{ color: net >= 0 ? "#22C55E" : "#EF4444" }}
      >
        {formatSignedCurrency(Math.abs(net), net >= 0 ? "INCOME" : "EXPENSE")}
      </Text>
    </View>
  );
}

function SpendingSnapshot({
  month,
  week,
  today,
}: {
  month: { income: number; expense: number };
  week: { income: number; expense: number };
  today: { income: number; expense: number };
}) {
  return (
    <Card className="mb-4 border-primary/40">
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center">
          <View className="mr-2 h-8 w-8 items-center justify-center rounded-full bg-primary/15">
            <Ionicons name="pulse-outline" size={16} color="#208AEF" />
          </View>
          <View>
            <Text className="text-base font-semibold text-white">
              Spending snapshot
            </Text>
            <Text className="mt-0.5 text-xs text-muted">
              Your money at a glance
            </Text>
          </View>
        </View>
      </View>

      <View className="mt-4 flex-row border-b border-border px-2 pb-2">
        <Text
          className="text-[10px] font-semibold uppercase tracking-wide text-muted"
          style={{ width: "24%", flexGrow: 0, flexShrink: 0 }}
          numberOfLines={1}
        >
          Period
        </Text>
        <Text className="w-[21%] text-right text-[10px] font-semibold uppercase tracking-wide text-muted">
          Money in
        </Text>
        <Text className="w-[21%] text-right text-[10px] font-semibold uppercase tracking-wide text-muted">
          Money out
        </Text>
        <Text className="w-[34%] text-right text-[10px] font-semibold uppercase tracking-wide text-muted">
          Left after spending
        </Text>
      </View>

      <SummaryRow
        label="This month"
        income={month.income}
        expense={month.expense}
        highlight
      />
      <SummaryRow
        label="This week"
        income={week.income}
        expense={week.expense}
      />
      <SummaryRow label="Today" income={today.income} expense={today.expense} />
    </Card>
  );
}

export default function HomeScreen() {
  const summary = useLedgerSummary();

  if (summary.isLoading) {
    return (
      <View className="flex-1 bg-background p-4">
        <Skeleton height={132} className="mb-4" />
        <Skeleton height={100} className="mb-4" />
        <Skeleton height={100} className="mb-4" />
        <Skeleton height={200} />
      </View>
    );
  }

  if (summary.isError) {
    return (
      <View className="flex-1 bg-background p-4">
        <ErrorState
          onRetry={() => void summary.refetch()}
          style={{ flex: 1 }}
        />
      </View>
    );
  }

  const data = summary.data;
  if (!data) return null;

  const isEmpty =
    data.today.income === 0 &&
    data.today.expense === 0 &&
    data.thisWeek.income === 0 &&
    data.thisWeek.expense === 0 &&
    data.thisMonth.income === 0 &&
    data.thisMonth.expense === 0;

  return (
    <ScrollView
      className="flex-1 bg-background px-4"
      contentContainerStyle={{ paddingTop: 12, paddingBottom: 112 }}
      refreshControl={
        <RefreshControl
          refreshing={summary.isRefetching}
          onRefresh={() => void summary.refetch()}
          tintColor="#208AEF"
          colors={["#208AEF"]}
        />
      }
    >
      <View className="mb-5 px-1">
        <Text className="text-2xl font-bold tracking-tight text-white">
          Your financial overview
        </Text>
        <Text className="mt-1 text-sm text-muted">
          See what came in, what went out, and what is left.
        </Text>
      </View>
      {isEmpty ? (
        <EmptyState
          title="Welcome to your home"
          message="Add entries to see your income, spending and trends here."
          icon={
            <Ionicons name="stats-chart-outline" size={48} color="#94A3B8" />
          }
          action={
            <Button
              title="Go to ledger"
              onPress={() => router.push("/ledger")}
            />
          }
        />
      ) : (
        <>
          <SpendingSnapshot
            month={data.thisMonth}
            week={data.thisWeek}
            today={data.today}
          />

          <SpendByCategory categories={data.categories} />
        </>
      )}

      <Card className="mb-4">
        <Text className="mb-3 text-base font-semibold text-white">
          Quick actions
        </Text>
        <View>
          <Button
            title="Open Ledger"
            variant="outline"
            fullWidth
            leftIcon={
              <Ionicons name="list-outline" size={18} color="#208AEF" />
            }
            onPress={() => router.push("/ledger")}
          />
          <Button
            title="Manage Subscriptions"
            variant="secondary"
            fullWidth
            leftIcon={
              <Ionicons name="card-outline" size={18} color="#FFFFFF" />
            }
            className="mt-3"
            onPress={() => router.push("/subscriptions")}
          />
        </View>
      </Card>
    </ScrollView>
  );
}
