import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import {
  FlatList,
  RefreshControl,
  Text,
  View,
} from "react-native";
import { Button, EmptyState, ErrorState, Skeleton } from "@/components/ui";
import { GoalCard } from "@/components/goal/GoalCard";
import { GoalForm } from "@/components/goal/GoalForm";
import { useGoals, type Goal } from "@/hooks/useGoals";
import { useNetworkStatus } from "@/hooks/useNetworkStatus";
import { formatCurrency } from "@/lib/format";

type GoalSkeleton = { kind: "skeleton"; key: string };
type GoalRow = Goal | GoalSkeleton;

export default function GoalsScreen() {
  const { isOnline } = useNetworkStatus();
  const [formVisible, setFormVisible] = useState(false);

  const goals = useGoals();

  const total = (goals.data ?? []).reduce(
    (acc, goal) => acc + goal.savedAmount,
    0,
  );

  const refresh = () => void goals.refetch();

  const openCreate = () => setFormVisible(true);

  const isLoading = goals.isLoading;
  const skeletonData: GoalSkeleton[] = isLoading
    ? Array.from({ length: 3 }).map((_, i) => ({ kind: "skeleton" as const, key: `s-${i}` }))
    : [];

  return (
    <View className="flex-1 bg-background">
      {(goals.data?.length ?? 0) > 0 ? (
        <View className="mx-4 mb-1 mt-3 flex-row items-center rounded-xl border border-border bg-surface px-4 py-3">
          <View className="mr-3 h-9 w-9 items-center justify-center rounded-full bg-primary/15">
            <Ionicons name="flag-outline" size={18} color="#208AEF" />
          </View>
          <View className="flex-1">
            <Text className="text-xs font-medium uppercase tracking-wide text-muted">Total saved</Text>
            <Text className="mt-0.5 text-lg font-semibold text-white">
              {formatCurrency(total)}
            </Text>
          </View>
        </View>
      ) : null}

      <FlatList
        className="flex-1 px-3"
        data={isLoading ? skeletonData : (goals.data ?? []) as GoalRow[]}
        keyExtractor={(item) => ("kind" in item ? item.key : item.id)}
        renderItem={({ item }) =>
          "kind" in item ? (
            <Skeleton height={96} className="mb-3" />
          ) : (
            <GoalCard
              goal={item}
              onPress={() => router.push(`/goal/${item.id}`)}
            />
          )
        }
        contentContainerStyle={{ paddingBottom: 120, flexGrow: 1 }}
        refreshControl={
          <RefreshControl
            refreshing={goals.isRefetching}
            onRefresh={refresh}
            tintColor="#208AEF"
            colors={["#208AEF"]}
          />
        }
        ListEmptyComponent={
          goals.isLoading ? null : goals.isError ? (
            <ErrorState onRetry={refresh} />
          ) : (
            <EmptyState
              title="No savings goals yet"
              message="Set a target and track your progress toward it."
              icon={<Ionicons name="flag-outline" size={48} color="#94A3B8" />}
              action={<Button title="Create your first goal" onPress={openCreate} />}
            />
          )
        }
      />

      <Button
        title=""
        size="sm"
        leftIcon={<Ionicons name="add" size={24} color="#FFFFFF" />}
        className="rounded-full bg-primary"
        style={{
          position: "absolute",
          right: 20,
          bottom: 104,
          width: 56,
          height: 56,
          minHeight: 56,
          paddingHorizontal: 0,
          paddingVertical: 0,
          borderRadius: 28,
          zIndex: 10,
          shadowColor: "#208AEF",
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.3,
          shadowRadius: 8,
        }}
        accessibilityLabel="Create goal"
        accessibilityHint="Opens the form to create a savings goal"
        onPress={openCreate}
      />

      <GoalForm
        visible={formVisible}
        initialValues={null}
        isOffline={!isOnline}
        onClose={() => setFormVisible(false)}
      />
    </View>
  );
}
