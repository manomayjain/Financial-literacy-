import { Ionicons } from "@expo/vector-icons";
import { Redirect, router, Tabs } from "expo-router";
import { Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { AlertsBell } from "@/components/alerts/AlertsBell";
import { useAuthStore } from "@/store/authStore";

type IoniconName = keyof typeof Ionicons.glyphMap;

const tabIcons: Record<string, { active: IoniconName; inactive: IoniconName }> =
  {
    dashboard: { active: "home", inactive: "home-outline" },
    goals: { active: "flag", inactive: "flag-outline" },
    learn: { active: "school", inactive: "school-outline" },
    profile: { active: "person", inactive: "person-outline" },
  };

export default function TabsLayout() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const insets = useSafeAreaInsets();

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/login" />;
  }

  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: "#0F172A" },
        headerTintColor: "#FFFFFF",
        tabBarStyle: {
          height: 68 + insets.bottom,
          paddingTop: 7,
          paddingBottom: 7 + insets.bottom,
          backgroundColor: "#0F172A",
          borderTopColor: "#334155",
        },
        tabBarItemStyle: { flex: 1 },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "600" },
        tabBarHideOnKeyboard: true,
        tabBarActiveTintColor: "#208AEF",
        tabBarInactiveTintColor: "#94A3B8",
        headerRight: () => <AlertsBell />,
      }}
    >
      {Object.entries(tabIcons).map(([name, icons]) => (
        <Tabs.Screen
          key={name}
          name={name}
          options={{
            title:
              name === "dashboard"
                ? "Home"
                : name.charAt(0).toUpperCase() + name.slice(1),
            tabBarIcon: ({ color, size, focused }) => (
              <Ionicons
                name={focused ? icons.active : icons.inactive}
                size={size}
                color={color}
              />
            ),
          }}
        />
      ))}
      <Tabs.Screen name="ledger" options={{ href: null, title: "Ledger" }} />
      <Tabs.Screen
        name="subscriptions"
        options={{
          href: null,
          title: "Subscriptions",
          headerLeft: () => (
            <Pressable
              onPress={() => router.back()}
              hitSlop={10}
              className="ml-3 h-9 w-9 items-center justify-center"
            >
              <Ionicons name="arrow-back" size={23} color="#FFFFFF" />
            </Pressable>
          ),
        }}
      />
    </Tabs>
  );
}
