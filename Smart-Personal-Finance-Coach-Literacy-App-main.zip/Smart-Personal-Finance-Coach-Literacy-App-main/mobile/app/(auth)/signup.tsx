import { zodResolver } from "@hookform/resolvers/zod";
import { Link, router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import {
  Image,
  ScrollView,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { z } from "zod";
import { Button, Card, ErrorState, Input } from "@/components/ui";
import { useSignup } from "@/hooks/useAuth";
import {
  getErrorCode,
  getErrorIssues,
  getErrorMessage,
  isNetworkError,
} from "@/lib/api";

const signupSchema = z
  .object({
    name: z
      .string()
      .trim()
      .min(1, "Name is required")
      .min(2, "Name must be at least 2 characters"),
    email: z
      .string()
      .trim()
      .min(1, "Email is required")
      .email("Enter a valid email address"),
    password: z
      .string()
      .min(1, "Password is required")
      .min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string().min(1, "Please confirm your password"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type SignupFormValues = z.infer<typeof signupSchema>;

export default function SignupScreen() {
  const signup = useSignup();

  const {
    control,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const networkError = signup.isError && isNetworkError(signup.error);
  const submitError =
    signup.isError && !networkError ? getErrorMessage(signup.error) : null;

  const onSubmit = (values: SignupFormValues) => {
    signup.mutate(
      {
        name: values.name,
        email: values.email,
        password: values.password,
      },
      {
        onSuccess: () => {
          router.replace("/dashboard");
        },
        onError: (error) => {
          if (getErrorCode(error) === "EMAIL_TAKEN") {
            setError("email", {
              message: "An account with this email already exists",
            });
            return;
          }

          const issues = getErrorIssues(error);
          if (issues) {
            for (const [field, messages] of Object.entries(issues)) {
              setError(field as keyof SignupFormValues, {
                message: messages[0],
              });
            }
          }
        },
      },
    );
  };

  const handleRetry = () => {
    void handleSubmit(onSubmit)();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-background"
    >
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: "center",
          paddingHorizontal: 24,
          paddingVertical: 40,
          paddingBottom: 80,
        }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
      >
        <View className="w-full max-w-md mx-auto">
          {/* Header */}
          <View className="mb-8 items-center">
            <Image
              source={require("@/assets/images/icon.png")}
              className="mb-4 h-16 w-16 rounded-2xl"
              accessibilityLabel="Smart Finance Coach logo"
            />
            <Text className="text-3xl font-extrabold text-white text-center tracking-tight">
              Create Account
            </Text>
            <Text className="mt-2 text-base text-muted text-center font-medium">
              Start building better money habits today.
            </Text>
          </View>

          {/* Form Card */}
          <Card
            padded={false}
            className="p-6 rounded-2xl border border-border bg-surface shadow-xl"
          >
            {networkError ? (
              <ErrorState
                title="Connection problem"
                message="We couldn't reach the server. Check your internet connection and try again."
                onRetry={handleRetry}
              />
            ) : (
              <View>
                <Controller
                  control={control}
                  name="name"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Full Name"
                      placeholder="Your name"
                      autoComplete="name"
                      textContentType="name"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.name?.message}
                      className="mb-4"
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="email"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Email Address"
                      placeholder="you@example.com"
                      autoCapitalize="none"
                      autoComplete="email"
                      keyboardType="email-address"
                      textContentType="emailAddress"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.email?.message}
                      className="mb-4"
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="password"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Password"
                      placeholder="At least 8 characters"
                      secureTextEntry
                      textContentType="newPassword"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.password?.message}
                      className="mb-4"
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="confirmPassword"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Confirm Password"
                      placeholder="Repeat your password"
                      secureTextEntry
                      textContentType="newPassword"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.confirmPassword?.message}
                      className="mb-5"
                    />
                  )}
                />

                {submitError ? (
                  <View className="bg-danger/10 border border-danger/20 rounded-xl p-3.5 mb-4">
                    <Text className="text-sm font-semibold text-danger text-center">
                      {submitError}
                    </Text>
                  </View>
                ) : null}

                <Button
                  title="Create Account"
                  fullWidth
                  loading={signup.isPending || isSubmitting}
                  loadingTitle="Creating account..."
                  disabled={signup.isPending || isSubmitting}
                  onPress={handleSubmit(onSubmit)}
                  style={{ height: 48, borderRadius: 12 }}
                />
              </View>
            )}
          </Card>

          {/* Footer Link */}
          <View className="mt-8 flex-row justify-center items-center">
            <Text className="text-sm text-muted font-medium">
              Already have an account?{" "}
            </Text>
            <Link
              href="/(auth)/login"
              className="text-sm font-semibold text-primary"
            >
              Sign in
            </Link>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
