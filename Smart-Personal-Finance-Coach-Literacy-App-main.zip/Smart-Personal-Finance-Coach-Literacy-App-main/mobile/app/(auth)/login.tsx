import { zodResolver } from "@hookform/resolvers/zod";
import { Link, router } from "expo-router";
import { Controller, useForm } from "react-hook-form";
import {
  Image,
  ScrollView,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { z } from "zod";
import { Button, Card, ErrorState, Input } from "@/components/ui";
import { useLogin } from "@/hooks/useAuth";
import { getErrorIssues, getErrorMessage, isNetworkError } from "@/lib/api";

const loginSchema = z.object({
  email: z
    .string()
    .trim()
    .min(1, "Email is required")
    .email("Enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function LoginScreen() {
  const login = useLogin();

  const {
    control,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const networkError = login.isError && isNetworkError(login.error);
  const submitError =
    login.isError && !networkError ? getErrorMessage(login.error) : null;

  const onSubmit = (values: LoginFormValues) => {
    login.mutate(values, {
      onSuccess: () => {
        router.replace("/dashboard");
      },
      onError: (error) => {
        const issues = getErrorIssues(error);
        if (issues) {
          for (const [field, messages] of Object.entries(issues)) {
            setError(field as keyof LoginFormValues, { message: messages[0] });
          }
        }
      },
    });
  };

  const handleRetry = () => {
    void handleSubmit(onSubmit)();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-background"
    >
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: "center",
          paddingHorizontal: 24,
          paddingVertical: 40,
          paddingBottom: 80,
        }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
      >
        <View className="w-full max-w-md mx-auto">
          {/* Header */}
          <View className="mb-8 items-center">
            <Image
              source={require("@/assets/images/icon.png")}
              className="mb-4 h-16 w-16 rounded-2xl"
              accessibilityLabel="Smart Finance Coach logo"
            />
            <Text className="text-3xl font-extrabold text-white text-center tracking-tight">
              Smart Finance Coach
            </Text>
            <Text className="mt-2 text-base text-muted text-center font-medium">
              Welcome back. Sign in to continue.
            </Text>
          </View>

          {/* Form Card */}
          <Card
            padded={false}
            className="p-6 rounded-2xl border border-border bg-surface shadow-xl"
          >
            {networkError ? (
              <ErrorState
                title="Connection problem"
                message="We couldn't reach the server. Check your internet connection and try again."
                onRetry={handleRetry}
              />
            ) : (
              <View>
                <Controller
                  control={control}
                  name="email"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Email Address"
                      placeholder="you@example.com"
                      autoCapitalize="none"
                      autoComplete="email"
                      keyboardType="email-address"
                      textContentType="emailAddress"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.email?.message}
                      className="mb-4"
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="password"
                  render={({ field: { onChange, onBlur, value } }) => (
                    <Input
                      label="Password"
                      placeholder="••••••••"
                      secureTextEntry
                      textContentType="password"
                      value={value}
                      onChangeText={onChange}
                      onBlur={onBlur}
                      error={errors.password?.message}
                      className="mb-5"
                    />
                  )}
                />

                {submitError ? (
                  <View className="bg-danger/10 border border-danger/20 rounded-xl p-3.5 mb-4">
                    <Text className="text-sm font-semibold text-danger text-center">
                      {submitError}
                    </Text>
                  </View>
                ) : null}

                <Button
                  title="Sign In"
                  fullWidth
                  loading={login.isPending || isSubmitting}
                  loadingTitle="Signing in..."
                  disabled={login.isPending || isSubmitting}
                  onPress={handleSubmit(onSubmit)}
                  style={{ height: 48, borderRadius: 12 }}
                />
              </View>
            )}
          </Card>

          {/* Footer Link */}
          <View className="mt-8 flex-row justify-center items-center">
            <Text className="text-sm text-muted font-medium">
              {"Don't"} have an account?{" "}
            </Text>
            <Link
              href="/(auth)/signup"
              className="text-sm font-semibold text-primary"
            >
              Sign up
            </Link>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
