import { QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import { useEffect } from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";

import { queryClient } from "@/lib/queryClient";
import { ensureNetworkMonitor } from "@/store/networkStore";
import { useAuthStore } from "@/store/authStore";
import { NetworkBanner } from "@/components/ui/NetworkBanner";
import { Toast } from "@/components/ui/Toast";

import "../global.css";

ensureNetworkMonitor();

export default function RootLayout() {
  const hydrate = useAuthStore((state) => state.hydrate);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  return (
    <SafeAreaProvider>
      <QueryClientProvider client={queryClient}>
        <StatusBar style="light" />
        <NetworkBanner />
        <Stack
          screenOptions={{
            headerStyle: { backgroundColor: "#0F172A" },
            headerTintColor: "#FFFFFF",
            contentStyle: { backgroundColor: "#0F172A" },
          }}
        >
          <Stack.Screen name="index" options={{ headerShown: false }} />
          <Stack.Screen name="(auth)" options={{ headerShown: false }} />
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="goal/[id]" options={{ title: "Goal" }} />
          <Stack.Screen name="article/[id]" options={{ title: "Article" }} />
          <Stack.Screen name="alerts" options={{ title: "Alerts" }} />
        </Stack>
        <Toast />
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}