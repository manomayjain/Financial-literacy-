export const TAG_LABELS: Record<string, string> = {
  food: "Food",
  entertainment: "Entertainment",
  shopping: "Shopping",
  subscriptions: "Subscriptions",
  "saving-basics": "Saving Basics",
  "budgeting-basics": "Budgeting Basics",
};

export function formatTag(tag: string): string {
  return TAG_LABELS[tag] ?? tag.charAt(0).toUpperCase() + tag.slice(1);
}