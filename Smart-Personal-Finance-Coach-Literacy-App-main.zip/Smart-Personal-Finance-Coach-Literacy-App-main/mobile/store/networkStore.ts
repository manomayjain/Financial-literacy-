import NetInfo, {
  NetInfoState,
  NetInfoStateType,
} from "@react-native-community/netinfo";
import { create } from "zustand";

export interface NetworkStatusState {
  isOnline: boolean;
  isInternetReachable: boolean | null;
  type: NetInfoStateType;
  details: NetInfoState["details"];
}

const initialState: NetworkStatusState = {
  isOnline: true,
  isInternetReachable: true,
  type: NetInfoStateType.unknown,
  details: null,
};

export const useNetworkStore = create<NetworkStatusState>(() => initialState);

let monitorStarted = false;

export function ensureNetworkMonitor(): void {
  if (monitorStarted) return;
  monitorStarted = true;
  NetInfo.addEventListener((state) => {
    useNetworkStore.setState({
      isOnline: state.isConnected === true,
      isInternetReachable: state.isInternetReachable,
      type: state.type,
      details: state.details,
    });
  });
}