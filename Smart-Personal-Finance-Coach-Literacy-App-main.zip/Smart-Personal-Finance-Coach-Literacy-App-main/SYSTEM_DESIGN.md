# Smart Finance Coach — System Design

A plain-language guide to what this app does, how it is put together, and how the "smart" parts actually work. Written so a non-technical evaluator can follow the logic without reading code. A technical appendix at the end covers deployment and demo build steps.

---

## 1. What the app is

**Smart Finance Coach** is a personal finance app for a phone. A user signs up, logs their income and spending ("ledger"), sets savings goals, and tracks recurring subscriptions like Netflix or a gym. It then does three "smart" things automatically:

1. **Warns the user when they overspend** — if a month-to-date category total passes a budget threshold, it creates an alert and suggests a related educational article.
2. **Reminds the user when bills are due** — every subscription's next charge date is calculated correctly (even for weird dates like the 31st in February), and an alert is raised within 3 days of the charge.
3. **Turns learning into progress** — short financial-education articles come with a 3-question quiz. Passing quizzes earns badges shown on the profile, giving gentle gamification.

There is no ad network, no third-party trackers, and no manual math: the numbers shown are computed from the user's own entries.

---

## 2. Architecture (how the pieces fit together)

The app is split into two parts that talk over the internet using a standard set of rules called HTTPS/JSON.

```
┌────────────────────────────┐        ┌──────────────────────────────┐
│  MOBILE APP (React Native) │  HTTPS │  BACKEND API (Express + TS)  │
│  Expo / React Native       │  JSON  │  business rules live here     │
│  - screens: dashboard,     │◄──────►│  - login & signup             │
│    ledger, goals, subs,    │        │  - rule engine (the "smart")  │
│    learn, alerts, profile  │        │  - quizzes & badges           │
└────────────────────────────┘        └──────────────┬───────────────┘
                                                     │ SQL (Prisma ORM)
                                                     ▼
                                           ┌─────────────────────────┐
                                           │  DATABASE (PostgreSQL,  │
                                           │  hosted on Neon)        │
                                           │  9 tables (see §3)      │
                                           └─────────────────────────┘
```

- **Mobile app** — built with React Native and Expo (the industry-standard cross-platform toolkit), so one codebase runs on both Android and iOS. It keeps the user signed in securely on the device and works gracefully offline: a banner appears when there is no connection, and anything that needs the server is disabled until the connection is back.
- **Backend API** — a TypeScript service built with Express. It never trusts the phone: every value is validated before it is stored, only the signed-in user's own data can be read or changed, and all rules are re-computed on the server so the app's "smartness" cannot be faked by the client.
- **Database** — a Postgres database hosted on Neon. The API talks to it through an object mapper (Prisma), which keeps the code type-safe and prevents a whole class of mistakes.

**Security in one paragraph:** passwords are never stored — only a one-way scrambled version (bcrypt) is kept. After signing in the server issues two short-lived "passwords" called tokens (JWT); the phone presents them on every request so the server knows who it is talking to. Because every data query includes the user's id, one person can never read or change another person's data: if they try, the server answers "not found", so it doesn't even reveal that the data exists.

---

## 3. Database schema and relationships

The database stores nine kinds of records. Reading "A has many B" means one record links to many others.

```
User ──┬── has many → Entry        (income/expense rows)
       ├── has many → Goal         (savings targets)
       ├── has many → Subscription (recurring bills)
       ├── has many → Alert        (the notifications it receives)
       └── has many → QuizAttempt  (quiz results, for badges)

Article ─── has one → Quiz ─── has many → Question   (a quiz belongs to one article)
Article ─── has many → Alert     (an alert can link to a helpful article)

Alerts link three concepts: the user who owns them, an article for further reading, and the rule that created them.
```

Table-by-table:

| Table | Stores | Key relationships | Who owns it |
|---|---|---|---|
| **User** | name, email, scrambled password | parent of nearly everything | — |
| **Entry** | one row of income or spending: type, category, amount, note, date | belongs to one User | User |
| **Goal** | savings target: title, target amount, saved-so-far, optional deadline | belongs to one User | User |
| **Subscription** | recurring bill: name, amount, day-of-month it charges | belongs to one User | User |
| **Alert** | a notification: type, message, read/unread | belongs to one User; may point at one Article | User |
| **Article** | educational reading: title, summary, body, topic tag | has one Quiz | shared (visible to all) |
| **Quiz** | a set of questions belonging to one article | belongs to one Article; has many Questions | shared |
| **Question** | one quiz question: text, answer options, and the **correct answer index** (kept server-side only) | belongs to one Quiz | shared |
| **QuizAttempt** | one result: which quiz, the score out of total | belongs to one User and one quiz | User |

**Why the design is safe:** shared content (articles, quizzes) has no owner, so everyone can read it. Everything personal (entries, goals, subscriptions, alerts, quiz attempts) carries the owning user's id, and every query the API makes filters by that id.

---

## 4. The rule engine — the "smart" part, explained

All rules live on the server and run automatically. This section explains each one in plain terms with a concrete example.

### 4.1 Overspend detection

**The idea.** People blow a budget in one category without noticing. The app watches each category month-to-date and warns the moment the total passes a sensible threshold.

**How it works.**
1. When a new expense is saved, the server re-adds up **all expenses of that category for the current calendar month** (start of the month to now).
2. It compares that running total to the category's threshold (e.g. Dining $400, Groceries $600, unknown categories a default of $400).
3. If the total is **above** the threshold and there isn't already an alert for that category this month, it creates an alert and links it to a matching educational article (e.g. an overspend on "Dining" links to the article tagged "Dining").

**Example.** Ada spends $150 on dining on the 1st and $260 on the 14th. At the 14th the month-to-date dining total is $410 — over the $400 threshold — so an alert appears: *"[Dining] You've spent $410.00 on Dining this month — over your $400.00 budget."* Spend is never double-counted: the 19th and 26th add more, but only one alert fires for Dining in August.

**Edge cases covered by tests.** Income never triggers this rule. Being exactly at the threshold does not fire (it must be strictly over). The count is per calendar month, so September's dining resets the total. Alerts are de-duplicated so re-saving never spams. If the database happens to be slow, the entry is still saved — alerts are best-effort and can never block the user.

### 4.2 Subscription due-date reminders

**The idea.** Subscriptions bill on a fixed day of the month. Computing the *next* charge date is deceptively tricky, so the server has a dedicated date engine and raises an alert when a charge is within 3 days.

**How it works.**
1. Every active subscription is checked: "how many days until the next charge?"
2. If that number is 0, 1, 2, or 3, an alert is created ("bills today", "bills tomorrow", or "bills in N days").
3. Alerts are de-duplicated per subscription and billing cycle, so the same bill never spams.

**The tricky date math (and why it is tested so heavily).**
- A bill on the **31st** in a month with fewer days "rolls over" to the last day of that month — 31 February becomes 28 February (or 29 in a leap year).
- A bill on the **1st** in December rolls into January **of the next year**.
- A bill due *today* resolves to today (0 days), and the count always counts whole days.
- The de-duplication window is anchored to the *previous* charge date, so a bill charged on the 20th can only produce one reminder per month.

**Example.** On the 19th of August, a gym membership billed on the 22nd creates: *"[Gym] Gym bills in 3 days — $40.00/mo."* A cheaper streaming service billed on the 5th does not, because it is 17 days away. If the user opens the app again the same day, the gym reminder does not duplicate.

### 4.3 Quizzes and badges

Articles teach a concept, then ask 3 questions. The **correct answers are stored only on the server**, so the phone cannot "cheat" the score. Every attempt is saved as its own record, and badges are computed from real attempt history:

- "First quiz" — complete any quiz.
- "Quiz streak" — complete 3 quizzes.
- "Quiz champion" — complete 5 quizzes.
- "Perfect score" — get a perfect score on any quiz.
- "Five passed" — pass 5 quizzes.

Badges show progress (e.g. 2/3), so the user always sees how close they are to the next one.

---

## 5. How we prove it works

- **75 automated unit tests** cover the rule engine and auth: overspend thresholds and de-duplication, subscription date math across leap years and short months, signup validation, duplicate emails, wrong-password logins, and invalid/expired tokens.
- **54 live end-to-end checks** run against a real database to prove every endpoint requires a login, rejects bad input, and — critically — that one account can never touch another's data.
- **A Postman collection** (in `server/postman/`) contains every endpoint with success and error cases, each asserting its expected response, ready to run in Postman, Thunder Client, or CI.

---

## Appendix A — Run it locally

**Backend.**
```
cd server
npm install
npx prisma generate
npx prisma migrate dev   # creates local DB tables
npx prisma seed          # loads educational articles + quizzes
npm run dev              # http://localhost:4000
```

**Mobile app (needs a device/emulator with Expo Go, or a web browser).**
```
cd mobile
npm install
npx expo start           # scan the QR code with Expo Go
```

---

## Appendix B — Deploy for the demo (technical)

### Backend on Render (or Railway)
1. Create a free Neon project and copy the Postgres connection string (`DATABASE_URL`).
2. Push this repository to GitHub, then in Render choose **New → Blueprint** and select this repo. Render reads `server/render.yaml` automatically.
3. During setup, Render will ask for the two secrets: `DATABASE_URL` and a long random `JWT_SECRET`. (`CLIENT_URL` defaults to the Expo web origin for browser access; native phones don't need CORS.)
4. Render runs database migrations, builds, and serves the API at a URL like `https://smart-finance-coach-api.onrender.com`. The `/api/v1/health` endpoint doubles as the health check.
5. **Verify CORS:** the server allows native phone requests with no origin, and browser requests from any origin listed in `CLIENT_URL`. In production set `CLIENT_URL` to wherever the web app is hosted.

Same idea on **Railway**: add a Node service, set the same environment variables, and use the commands `npx prisma migrate deploy && npx prisma generate && npm run build` for build and `node dist/server.js` for start.

### Mobile demo build (no dev server needed)
```
cd mobile
npm install -g eas-cli        # if not present
eas login                     # connect an Expo account
eas init                      # registers the project (one time)
npx eas build --profile preview --platform android
```
Before building, set the deployed API URL once so the app talks to the live backend instead of `localhost`:

```
# in eas.json under the preview profile:
"env": { "EXPO_PUBLIC_API_URL": "https://smart-finance-coach-api.onrender.com/api/v1" }
```

The preview profile builds an installable Android APK (`com.smartfinancecoach.app`) that you can download from the EAS page and side-load onto any phone — it runs standalone with no dev server. The same project also runs in **Expo Go** during development via `npx expo start`.

> Note: `EXPO_PUBLIC_API_URL` is baked into the build, so rebuild after changing it. Only native code is compiled; all app logic is the JavaScript bundle from this repository.